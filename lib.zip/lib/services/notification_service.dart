import 'package:firebase_messaging/firebase_messaging.dart';

class NotificationService {
static final FirebaseMessaging _messaging =
FirebaseMessaging.instance;

static Future<void> initialize() async {
try {
await _messaging.requestPermission(
alert: true,
badge: true,
sound: true,
);


  await _messaging.subscribeToTopic('gzu_sports_test');

  final token = await _messaging.getToken();

  print('GZU SPORTS FCM TOKEN: $token');

  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    print('GZU SPORTS NOTIFICATION RECEIVED');

    if (message.notification != null) {
      print('Title: ${message.notification!.title}');
      print('Body: ${message.notification!.body}');
    }
  });
} catch (e) {
  print('GZU SPORTS NOTIFICATION ERROR: $e');
}


}
}
