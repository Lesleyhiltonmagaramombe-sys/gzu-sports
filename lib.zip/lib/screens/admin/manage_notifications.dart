import 'package:flutter/material.dart';

class ManageNotifications extends StatefulWidget {
  const ManageNotifications({super.key});

  @override
  State<ManageNotifications> createState() =>
      _ManageNotificationsState();
}

class _ManageNotificationsState
    extends State<ManageNotifications> {
  final List<Map<String, String>> _notifications = [
    {
      'type': 'Fixture',
      'title': 'New Fixture Added',
      'message':
          'Mashava will face City Campus in an upcoming rugby fixture.',
      'date': '2 hours ago',
    },
    {
      'type': 'Result',
      'title': 'Match Result Available',
      'message':
          'GZU Main defeated Mucheke 2–1 in the latest football match.',
      'date': 'Yesterday',
    },
    {
      'type': 'Reminder',
      'title': 'Match Reminder',
      'message':
          'Rugby Mashava vs City Campus starts Saturday at 15:00.',
      'date': 'Yesterday',
    },
    {
      'type': 'Update',
      'title': 'Sports Hub Updated',
      'message':
          'Fixtures and results have been updated on GZU Sports Hub.',
      'date': '3 days ago',
    },
  ];

  final List<String> _types = [
    'Fixture',
    'Result',
    'Reminder',
    'Update',
  ];

  Color _typeColor(String type) {
    switch (type) {
      case 'Fixture':
        return const Color(0xFF0F3D24);
      case 'Result':
        return const Color(0xFF1B7A47);
      case 'Reminder':
        return const Color(0xFF8A6500);
      case 'Update':
        return const Color(0xFF315A78);
      default:
        return const Color(0xFF0F3D24);
    }
  }

  void _showNotificationDialog({
    int? editIndex,
  }) {
    final isEditing = editIndex != null;

    final typeController = TextEditingController(
      text: isEditing
          ? _notifications[editIndex]['type']
          : 'Fixture',
    );

    final titleController = TextEditingController(
      text: isEditing
          ? _notifications[editIndex]['title']
          : '',
    );

    final messageController = TextEditingController(
      text: isEditing
          ? _notifications[editIndex]['message']
          : '',
    );

    String selectedType = typeController.text;

    showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(
                isEditing
                    ? 'Edit Notification'
                    : 'Create Notification',
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                ),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      initialValue: selectedType,
                      decoration: InputDecoration(
                        labelText: 'Notification Type',
                        border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(12),
                        ),
                      ),
                      items: _types.map((type) {
                        return DropdownMenuItem(
                          value: type,
                          child: Text(type),
                        );
                      }).toList(),
                      onChanged: (value) {
                        if (value == null) return;

                        setDialogState(() {
                          selectedType = value;
                        });
                      },
                    ),

                    const SizedBox(height: 14),

                    TextField(
                      controller: titleController,
                      decoration: InputDecoration(
                        labelText: 'Title',
                        hintText:
                            'e.g. New Fixture Added',
                        border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(12),
                        ),
                      ),
                    ),

                    const SizedBox(height: 14),

                    TextField(
                      controller: messageController,
                      maxLines: 4,
                      decoration: InputDecoration(
                        labelText: 'Message',
                        hintText:
                            'Enter the notification message',
                        alignLabelWithHint: true,
                        border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(dialogContext);
                  },
                  child: const Text('Cancel'),
                ),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        const Color(0xFF0F3D24),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: () {
                    final title =
                        titleController.text.trim();

                    final message =
                        messageController.text.trim();

                    if (title.isEmpty ||
                        message.isEmpty) {
                      ScaffoldMessenger.of(context)
                          .showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Please complete all fields.',
                          ),
                        ),
                      );

                      return;
                    }

                    setState(() {
                      final notification = {
                        'type': selectedType,
                        'title': title,
                        'message': message,
                        'date': isEditing
                            ? _notifications[
                                editIndex]['date']!
                            : 'Just now',
                      };

                      if (isEditing) {
                        _notifications[editIndex] =
                            notification;
                      } else {
                        _notifications.insert(
                          0,
                          notification,
                        );
                      }
                    });

                    Navigator.pop(dialogContext);

                    ScaffoldMessenger.of(context)
                        .showSnackBar(
                      SnackBar(
                        content: Text(
                          isEditing
                              ? 'Notification updated.'
                              : 'Notification created.',
                        ),
                      ),
                    );
                  },
                  child: Text(
                    isEditing ? 'Save Changes' : 'Create',
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _deleteNotification(int index) {
    final notification = _notifications[index];

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Delete Notification',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
          content: Text(
            'Are you sure you want to delete "${notification['title']}"?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFFB3261E),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                setState(() {
                  _notifications.removeAt(index);
                });

                Navigator.pop(dialogContext);

                ScaffoldMessenger.of(context)
                    .showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Notification deleted.',
                    ),
                  ),
                );
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  void _publishNotification(
    Map<String, String> notification,
  ) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Published: ${notification['title']}',
        ),
        backgroundColor:
            const Color(0xFF0F3D24),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),

      appBar: AppBar(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Manage Notifications',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        onPressed: () {
          _showNotificationDialog();
        },
        icon: const Icon(
          Icons.add_rounded,
        ),
        label: const Text(
          'Create',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      body: _notifications.isEmpty
          ? _emptyState()
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(
                20,
                20,
                20,
                100,
              ),
              itemCount: _notifications.length,
              itemBuilder: (context, index) {
                final notification =
                    _notifications[index];

                return _notificationCard(
                  notification,
                  index,
                );
              },
            ),
    );
  }

  Widget _notificationCard(
    Map<String, String> notification,
    int index,
  ) {
    final type = notification['type']!;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color: const Color(0xFFE1E6E2),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: _typeColor(type)
                      .withValues(alpha: 0.10),
                  borderRadius:
                      BorderRadius.circular(8),
                ),
                child: Text(
                  type.toUpperCase(),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: _typeColor(type),
                  ),
                ),
              ),

              const Spacer(),

              PopupMenuButton<String>(
                icon: const Icon(
                  Icons.more_vert_rounded,
                  color: Color(0xFF68716B),
                ),
                onSelected: (value) {
                  if (value == 'edit') {
                    _showNotificationDialog(
                      editIndex: index,
                    );
                  }

                  if (value == 'delete') {
                    _deleteNotification(index);
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(
                          Icons.edit_rounded,
                          size: 18,
                        ),
                        SizedBox(width: 10),
                        Text('Edit'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(
                          Icons.delete_outline_rounded,
                          size: 18,
                        ),
                        SizedBox(width: 10),
                        Text('Delete'),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 13),

          Text(
            notification['title']!,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: Color(0xFF141B16),
            ),
          ),

          const SizedBox(height: 6),

          Text(
            notification['message']!,
            style: const TextStyle(
              fontSize: 13,
              height: 1.45,
              color: Color(0xFF68716B),
            ),
          ),

          const SizedBox(height: 14),

          Row(
            children: [
              const Icon(
                Icons.access_time_rounded,
                size: 15,
                color: Color(0xFF9AA39D),
              ),

              const SizedBox(width: 5),

              Text(
                notification['date']!,
                style: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFF9AA39D),
                ),
              ),

              const Spacer(),

              TextButton.icon(
                onPressed: () {
                  _publishNotification(
                    notification,
                  );
                },
                icon: const Icon(
                  Icons.send_rounded,
                  size: 16,
                ),
                label: const Text(
                  'Publish',
                ),
                style: TextButton.styleFrom(
                  foregroundColor:
                      const Color(0xFF0F3D24),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3EC),
                borderRadius:
                    BorderRadius.circular(22),
              ),
              child: const Icon(
                Icons.notifications_none_rounded,
                size: 34,
                color: Color(0xFF0F3D24),
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'No notifications yet',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: Color(0xFF141B16),
              ),
            ),

            const SizedBox(height: 7),

            const Text(
              'Create a notification to keep sports users updated.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF68716B),
                height: 1.4,
              ),
            ),

            const SizedBox(height: 20),

            ElevatedButton.icon(
              onPressed: () {
                _showNotificationDialog();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              icon: const Icon(
                Icons.add_rounded,
              ),
              label: const Text(
                'Create Notification',
              ),
            ),
          ],
        ),
      ),
    );
  }
}