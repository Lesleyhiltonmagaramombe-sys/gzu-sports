import 'package:flutter/material.dart';

class ManageTeams extends StatefulWidget {
  const ManageTeams({super.key});

  @override
  State<ManageTeams> createState() => _ManageTeamsState();
}

class _ManageTeamsState extends State<ManageTeams> {
  final List<Map<String, String>> teams = [
    {
      'name': 'Mashava',
      'sport': 'Rugby',
      'players': '24',
    },
    {
      'name': 'GZU Main',
      'sport': 'Football',
      'players': '22',
    },
    {
      'name': 'GZU Titans',
      'sport': 'Basketball',
      'players': '15',
    },
    {
      'name': 'GZU Queens',
      'sport': 'Netball',
      'players': '14',
    },
    {
      'name': 'City Campus',
      'sport': 'Rugby',
      'players': '23',
    },
    {
      'name': 'Mucheke',
      'sport': 'Football',
      'players': '21',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),

      appBar: AppBar(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Manage Teams',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: const Color(0xFFB8FF3C),
        onPressed: () {
          _showAddTeamDialog(context);
        },
        child: const Icon(Icons.add_rounded),
      ),

      body: teams.isEmpty
          ? _emptyState()
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
              itemCount: teams.length,
              itemBuilder: (context, index) {
                return _teamCard(
                  teams[index],
                  index,
                );
              },
            ),
    );
  }

  Widget _teamCard(
    Map<String, String> team,
    int index,
  ) {
    final name = team['name'] ?? '';
    final sport = team['sport'] ?? '';
    final players = team['players'] ?? '0';

    final cleanName = name.trim();

    final parts = cleanName
        .split(RegExp(r'\s+'))
        .where((part) => part.isNotEmpty)
        .toList();

    final initials = parts.length >= 2
        ? parts
            .take(2)
            .map((part) => part[0])
            .join()
            .toUpperCase()
        : cleanName.length <= 3
            ? cleanName.toUpperCase()
            : cleanName.substring(0, 3).toUpperCase();

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: const Color(0xFFE1E6E2),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: const Color(0xFF0F3D24),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Center(
              child: Text(
                initials,
                style: const TextStyle(
                  color: Color(0xFFB8FF3C),
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),

          const SizedBox(width: 15),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF141B16),
                  ),
                ),

                const SizedBox(height: 5),

                Text(
                  sport,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF1B7A47),
                  ),
                ),

                const SizedBox(height: 5),

                Row(
                  children: [
                    const Icon(
                      Icons.groups_rounded,
                      size: 15,
                      color: Color(0xFF68716B),
                    ),

                    const SizedBox(width: 5),

                    Text(
                      '$players players',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF68716B),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          PopupMenuButton<String>(
            icon: const Icon(
              Icons.more_vert_rounded,
              color: Color(0xFF68716B),
            ),
            onSelected: (value) {
              if (value == 'edit') {
                _showEditTeamDialog(
                  context,
                  index,
                );
              }

              if (value == 'delete') {
                _deleteTeam(index);
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(
                value: 'edit',
                child: Text('Edit team'),
              ),
              PopupMenuItem(
                value: 'delete',
                child: Text('Delete team'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3EC),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.groups_rounded,
                size: 34,
                color: Color(0xFF0F3D24),
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'No teams yet',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w800,
                color: Color(0xFF141B16),
              ),
            ),

            const SizedBox(height: 7),

            const Text(
              'Add a sports team using the + button.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF68716B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddTeamDialog(BuildContext context) {
    final nameController = TextEditingController();
    final sportController = TextEditingController();
    final playersController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Add Team',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(
                  nameController,
                  'Team Name',
                  Icons.groups_rounded,
                ),

                _dialogField(
                  sportController,
                  'Sport',
                  Icons.sports_rounded,
                ),

                _dialogField(
                  playersController,
                  'Number of Players',
                  Icons.people_alt_rounded,
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                if (nameController.text.trim().isEmpty ||
                    sportController.text.trim().isEmpty ||
                    playersController.text.trim().isEmpty) {
                  return;
                }

                setState(() {
                  teams.add({
                    'name': nameController.text.trim(),
                    'sport': sportController.text.trim(),
                    'players': playersController.text.trim(),
                  });
                });

                Navigator.pop(context);
              },
              child: const Text('Add Team'),
            ),
          ],
        );
      },
    );
  }

  void _showEditTeamDialog(
    BuildContext context,
    int index,
  ) {
    final team = teams[index];

    final nameController = TextEditingController(
      text: team['name'],
    );

    final sportController = TextEditingController(
      text: team['sport'],
    );

    final playersController = TextEditingController(
      text: team['players'],
    );

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Edit Team',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(
                  nameController,
                  'Team Name',
                  Icons.groups_rounded,
                ),

                _dialogField(
                  sportController,
                  'Sport',
                  Icons.sports_rounded,
                ),

                _dialogField(
                  playersController,
                  'Number of Players',
                  Icons.people_alt_rounded,
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                if (nameController.text.trim().isEmpty ||
                    sportController.text.trim().isEmpty ||
                    playersController.text.trim().isEmpty) {
                  return;
                }

                setState(() {
                  teams[index] = {
                    'name': nameController.text.trim(),
                    'sport': sportController.text.trim(),
                    'players': playersController.text.trim(),
                  };
                });

                Navigator.pop(context);
              },
              child: const Text('Save Changes'),
            ),
          ],
        );
      },
    );
  }

  Widget _dialogField(
    TextEditingController controller,
    String label,
    IconData icon, {
    TextInputType? keyboardType,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  void _deleteTeam(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Delete Team?',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: const Text(
            'This team will be removed from the admin list.',
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            TextButton(
              onPressed: () {
                setState(() {
                  teams.removeAt(index);
                });

                Navigator.pop(context);
              },
              child: const Text(
                'Delete',
                style: TextStyle(
                  color: Colors.red,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}