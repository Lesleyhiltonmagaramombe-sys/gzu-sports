import 'package:flutter/material.dart';

class ManageFixtures extends StatefulWidget {
  const ManageFixtures({super.key});

  @override
  State<ManageFixtures> createState() => _ManageFixturesState();
}

class _ManageFixturesState extends State<ManageFixtures> {
  final List<Map<String, String>> fixtures = [
    {
      'sport': 'Rugby',
      'home': 'Mashava',
      'away': 'City Campus',
      'date': '12 Sep 2026',
      'time': '15:00',
      'venue': 'Primary Field',
    },
    {
      'sport': 'Football',
      'home': 'GZU Main',
      'away': 'Mucheke',
      'date': '15 Sep 2026',
      'time': '14:00',
      'venue': 'Main Sports Ground',
    },
    {
      'sport': 'Basketball',
      'home': 'GZU Titans',
      'away': 'Mashava',
      'date': '18 Sep 2026',
      'time': '16:00',
      'venue': 'Indoor Court',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),

      appBar: AppBar(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Manage Fixtures',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: const Color(0xFFB8FF3C),
        onPressed: () {
          _showAddFixtureDialog(context);
        },
        child: const Icon(Icons.add_rounded),
      ),

      body: fixtures.isEmpty
          ? _emptyState()
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
              itemCount: fixtures.length,
              itemBuilder: (context, index) {
                final fixture = fixtures[index];

                return _fixtureCard(
                  fixture,
                  index,
                );
              },
            ),
    );
  }

  Widget _fixtureCard(
    Map<String, String> fixture,
    int index,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: const Color(0xFFE1E6E2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // Sport and menu
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F3EC),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  fixture['sport'] ?? '',
                  style: const TextStyle(
                    color: Color(0xFF0F3D24),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              const Spacer(),

              PopupMenuButton<String>(
                icon: const Icon(
                  Icons.more_vert_rounded,
                  color: Color(0xFF68716B),
                ),
                onSelected: (value) {
                  if (value == 'edit') {
                    _showEditFixtureDialog(
                      context,
                      index,
                    );
                  }

                  if (value == 'delete') {
                    _deleteFixture(index);
                  }
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'edit',
                    child: Text('Edit fixture'),
                  ),
                  PopupMenuItem(
                    value: 'delete',
                    child: Text('Delete fixture'),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 18),

          // Teams
          Row(
            children: [
              Expanded(
                child: _teamName(
                  fixture['home'] ?? '',
                  'HOME',
                ),
              ),

              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Text(
                  'VS',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF9AA39D),
                  ),
                ),
              ),

              Expanded(
                child: _teamName(
                  fixture['away'] ?? '',
                  'AWAY',
                  right: true,
                ),
              ),
            ],
          ),

          const SizedBox(height: 18),

          const Divider(
            height: 1,
            color: Color(0xFFE8ECE9),
          ),

          const SizedBox(height: 14),

          // Date
          Row(
            children: [
              const Icon(
                Icons.calendar_today_rounded,
                size: 16,
                color: Color(0xFF1B7A47),
              ),

              const SizedBox(width: 8),

              Text(
                fixture['date'] ?? '',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF39423C),
                ),
              ),

              const SizedBox(width: 18),

              const Icon(
                Icons.access_time_rounded,
                size: 16,
                color: Color(0xFF1B7A47),
              ),

              const SizedBox(width: 7),

              Text(
                fixture['time'] ?? '',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF39423C),
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          // Venue
          Row(
            children: [
              const Icon(
                Icons.location_on_outlined,
                size: 17,
                color: Color(0xFF1B7A47),
              ),

              const SizedBox(width: 8),

              Expanded(
                child: Text(
                  fixture['venue'] ?? '',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF68716B),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _teamName(
    String name,
    String label, {
    bool right = false,
  }) {
    return Column(
      crossAxisAlignment:
          right ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 1,
            color: Color(0xFF9AA39D),
          ),
        ),

        const SizedBox(height: 5),

        Text(
          name,
          textAlign: right ? TextAlign.end : TextAlign.start,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: Color(0xFF141B16),
          ),
        ),
      ],
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3EC),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.calendar_month_rounded,
                size: 34,
                color: Color(0xFF0F3D24),
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'No fixtures yet',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w800,
                color: Color(0xFF141B16),
              ),
            ),

            const SizedBox(height: 7),

            const Text(
              'Add a fixture using the + button.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF68716B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddFixtureDialog(BuildContext context) {
    final sportController = TextEditingController();
    final homeController = TextEditingController();
    final awayController = TextEditingController();
    final dateController = TextEditingController();
    final timeController = TextEditingController();
    final venueController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Add Fixture',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(
                  sportController,
                  'Sport',
                  Icons.sports_rounded,
                ),
                _dialogField(
                  homeController,
                  'Home Team',
                  Icons.home_rounded,
                ),
                _dialogField(
                  awayController,
                  'Away Team',
                  Icons.groups_rounded,
                ),
                _dialogField(
                  dateController,
                  'Date',
                  Icons.calendar_today_rounded,
                ),
                _dialogField(
                  timeController,
                  'Time',
                  Icons.access_time_rounded,
                ),
                _dialogField(
                  venueController,
                  'Venue',
                  Icons.location_on_outlined,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                if (sportController.text.trim().isEmpty ||
                    homeController.text.trim().isEmpty ||
                    awayController.text.trim().isEmpty) {
                  return;
                }

                setState(() {
                  fixtures.add({
                    'sport': sportController.text.trim(),
                    'home': homeController.text.trim(),
                    'away': awayController.text.trim(),
                    'date': dateController.text.trim().isEmpty
                        ? 'Date not set'
                        : dateController.text.trim(),
                    'time': timeController.text.trim().isEmpty
                        ? 'Time not set'
                        : timeController.text.trim(),
                    'venue': venueController.text.trim().isEmpty
                        ? 'Venue not set'
                        : venueController.text.trim(),
                  });
                });

                Navigator.pop(context);
              },
              child: const Text('Add Fixture'),
            ),
          ],
        );
      },
    );
  }

  void _showEditFixtureDialog(
    BuildContext context,
    int index,
  ) {
    final fixture = fixtures[index];

    final sportController = TextEditingController(
      text: fixture['sport'],
    );

    final homeController = TextEditingController(
      text: fixture['home'],
    );

    final awayController = TextEditingController(
      text: fixture['away'],
    );

    final dateController = TextEditingController(
      text: fixture['date'],
    );

    final timeController = TextEditingController(
      text: fixture['time'],
    );

    final venueController = TextEditingController(
      text: fixture['venue'],
    );

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Edit Fixture',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(
                  sportController,
                  'Sport',
                  Icons.sports_rounded,
                ),
                _dialogField(
                  homeController,
                  'Home Team',
                  Icons.home_rounded,
                ),
                _dialogField(
                  awayController,
                  'Away Team',
                  Icons.groups_rounded,
                ),
                _dialogField(
                  dateController,
                  'Date',
                  Icons.calendar_today_rounded,
                ),
                _dialogField(
                  timeController,
                  'Time',
                  Icons.access_time_rounded,
                ),
                _dialogField(
                  venueController,
                  'Venue',
                  Icons.location_on_outlined,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                setState(() {
                  fixtures[index] = {
                    'sport': sportController.text.trim(),
                    'home': homeController.text.trim(),
                    'away': awayController.text.trim(),
                    'date': dateController.text.trim(),
                    'time': timeController.text.trim(),
                    'venue': venueController.text.trim(),
                  };
                });

                Navigator.pop(context);
              },
              child: const Text('Save Changes'),
            ),
          ],
        );
      },
    );
  }

  Widget _dialogField(
    TextEditingController controller,
    String label,
    IconData icon,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  void _deleteFixture(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Delete Fixture?',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
          content: const Text(
            'This fixture will be removed from the admin list.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            TextButton(
              onPressed: () {
                setState(() {
                  fixtures.removeAt(index);
                });

                Navigator.pop(context);
              },
              child: const Text(
                'Delete',
                style: TextStyle(
                  color: Colors.red,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}