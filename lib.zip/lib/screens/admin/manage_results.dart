import 'package:flutter/material.dart';

class ManageResults extends StatefulWidget {
  const ManageResults({super.key});

  @override
  State<ManageResults> createState() => _ManageResultsState();
}

class _ManageResultsState extends State<ManageResults> {
  final List<Map<String, String>> results = [
    {
      'sport': 'Rugby',
      'home': 'Mashava',
      'away': 'City Campus',
      'homeScore': '24',
      'awayScore': '12',
      'date': '05 Sep 2026',
      'venue': 'Primary Field',
    },
    {
      'sport': 'Football',
      'home': 'GZU Main',
      'away': 'Mucheke',
      'homeScore': '2',
      'awayScore': '1',
      'date': '03 Sep 2026',
      'venue': 'Main Sports Ground',
    },
    {
      'sport': 'Basketball',
      'home': 'GZU Titans',
      'away': 'Mashava',
      'homeScore': '68',
      'awayScore': '61',
      'date': '01 Sep 2026',
      'venue': 'Indoor Court',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),

      appBar: AppBar(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Manage Results',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: const Color(0xFFB8FF3C),
        onPressed: () {
          _showAddResultDialog(context);
        },
        child: const Icon(Icons.add_rounded),
      ),

      body: results.isEmpty
          ? _emptyState()
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
              itemCount: results.length,
              itemBuilder: (context, index) {
                return _resultCard(
                  results[index],
                  index,
                );
              },
            ),
    );
  }

  Widget _resultCard(
    Map<String, String> result,
    int index,
  ) {
    final homeScore =
        int.tryParse(result['homeScore'] ?? '0') ?? 0;

    final awayScore =
        int.tryParse(result['awayScore'] ?? '0') ?? 0;

    String winner;

    if (homeScore > awayScore) {
      winner = 'HOME WIN';
    } else if (awayScore > homeScore) {
      winner = 'AWAY WIN';
    } else {
      winner = 'DRAW';
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: const Color(0xFFE1E6E2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F3EC),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  result['sport'] ?? '',
                  style: const TextStyle(
                    color: Color(0xFF0F3D24),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              const SizedBox(width: 8),

              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 9,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFF0F2F0),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  winner,
                  style: const TextStyle(
                    color: Color(0xFF68716B),
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),

              const Spacer(),

              PopupMenuButton<String>(
                icon: const Icon(
                  Icons.more_vert_rounded,
                  color: Color(0xFF68716B),
                ),
                onSelected: (value) {
                  if (value == 'edit') {
                    _showEditResultDialog(
                      context,
                      index,
                    );
                  }

                  if (value == 'delete') {
                    _deleteResult(index);
                  }
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'edit',
                    child: Text('Edit result'),
                  ),
                  PopupMenuItem(
                    value: 'delete',
                    child: Text('Delete result'),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 20),

          // Score section
          Row(
            children: [
              Expanded(
                child: _teamScore(
                  result['home'] ?? '',
                  result['homeScore'] ?? '0',
                  'HOME',
                  homeScore > awayScore,
                ),
              ),

              Container(
                margin: const EdgeInsets.symmetric(
                  horizontal: 12,
                ),
                child: const Text(
                  '-',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF9AA39D),
                  ),
                ),
              ),

              Expanded(
                child: _teamScore(
                  result['away'] ?? '',
                  result['awayScore'] ?? '0',
                  'AWAY',
                  awayScore > homeScore,
                  right: true,
                ),
              ),
            ],
          ),

          const SizedBox(height: 18),

          const Divider(
            height: 1,
            color: Color(0xFFE8ECE9),
          ),

          const SizedBox(height: 14),

          Row(
            children: [
              const Icon(
                Icons.calendar_today_rounded,
                size: 16,
                color: Color(0xFF1B7A47),
              ),

              const SizedBox(width: 8),

              Text(
                result['date'] ?? '',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF39423C),
                ),
              ),

              const SizedBox(width: 18),

              const Icon(
                Icons.location_on_outlined,
                size: 17,
                color: Color(0xFF1B7A47),
              ),

              const SizedBox(width: 7),

              Expanded(
                child: Text(
                  result['venue'] ?? '',
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF68716B),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _teamScore(
    String team,
    String score,
    String label,
    bool winner, {
    bool right = false,
  }) {
    return Column(
      crossAxisAlignment:
          right ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 1,
            color: Color(0xFF9AA39D),
          ),
        ),

        const SizedBox(height: 5),

        Text(
          team,
          textAlign: right ? TextAlign.end : TextAlign.start,
          style: TextStyle(
            fontSize: 15,
            fontWeight: winner
                ? FontWeight.w800
                : FontWeight.w600,
            color: const Color(0xFF141B16),
          ),
        ),

        const SizedBox(height: 3),

        Text(
          score,
          style: TextStyle(
            fontSize: 27,
            fontWeight: FontWeight.w900,
            color: winner
                ? const Color(0xFF0F3D24)
                : const Color(0xFF68716B),
          ),
        ),
      ],
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3EC),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.scoreboard_rounded,
                size: 34,
                color: Color(0xFF0F3D24),
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'No results yet',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w800,
                color: Color(0xFF141B16),
              ),
            ),

            const SizedBox(height: 7),

            const Text(
              'Add a match result using the + button.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF68716B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddResultDialog(BuildContext context) {
    final sportController = TextEditingController();
    final homeController = TextEditingController();
    final awayController = TextEditingController();
    final homeScoreController = TextEditingController();
    final awayScoreController = TextEditingController();
    final dateController = TextEditingController();
    final venueController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Add Result',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(
                  sportController,
                  'Sport',
                  Icons.sports_rounded,
                ),

                _dialogField(
                  homeController,
                  'Home Team',
                  Icons.home_rounded,
                ),

                _dialogField(
                  awayController,
                  'Away Team',
                  Icons.groups_rounded,
                ),

                Row(
                  children: [
                    Expanded(
                      child: _dialogField(
                        homeScoreController,
                        'Home Score',
                        Icons.looks_one_rounded,
                        keyboardType: TextInputType.number,
                      ),
                    ),

                    const SizedBox(width: 10),

                    Expanded(
                      child: _dialogField(
                        awayScoreController,
                        'Away Score',
                        Icons.looks_two_rounded,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),

                _dialogField(
                  dateController,
                  'Date',
                  Icons.calendar_today_rounded,
                ),

                _dialogField(
                  venueController,
                  'Venue',
                  Icons.location_on_outlined,
                ),
              ],
            ),
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                if (sportController.text.trim().isEmpty ||
                    homeController.text.trim().isEmpty ||
                    awayController.text.trim().isEmpty ||
                    homeScoreController.text.trim().isEmpty ||
                    awayScoreController.text.trim().isEmpty) {
                  return;
                }

                setState(() {
                  results.add({
                    'sport': sportController.text.trim(),
                    'home': homeController.text.trim(),
                    'away': awayController.text.trim(),
                    'homeScore':
                        homeScoreController.text.trim(),
                    'awayScore':
                        awayScoreController.text.trim(),
                    'date': dateController.text.trim().isEmpty
                        ? 'Date not set'
                        : dateController.text.trim(),
                    'venue': venueController.text.trim().isEmpty
                        ? 'Venue not set'
                        : venueController.text.trim(),
                  });
                });

                Navigator.pop(context);
              },
              child: const Text('Add Result'),
            ),
          ],
        );
      },
    );
  }

  void _showEditResultDialog(
    BuildContext context,
    int index,
  ) {
    final result = results[index];

    final sportController = TextEditingController(
      text: result['sport'],
    );

    final homeController = TextEditingController(
      text: result['home'],
    );

    final awayController = TextEditingController(
      text: result['away'],
    );

    final homeScoreController = TextEditingController(
      text: result['homeScore'],
    );

    final awayScoreController = TextEditingController(
      text: result['awayScore'],
    );

    final dateController = TextEditingController(
      text: result['date'],
    );

    final venueController = TextEditingController(
      text: result['venue'],
    );

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Edit Result',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(
                  sportController,
                  'Sport',
                  Icons.sports_rounded,
                ),

                _dialogField(
                  homeController,
                  'Home Team',
                  Icons.home_rounded,
                ),

                _dialogField(
                  awayController,
                  'Away Team',
                  Icons.groups_rounded,
                ),

                Row(
                  children: [
                    Expanded(
                      child: _dialogField(
                        homeScoreController,
                        'Home Score',
                        Icons.looks_one_rounded,
                        keyboardType: TextInputType.number,
                      ),
                    ),

                    const SizedBox(width: 10),

                    Expanded(
                      child: _dialogField(
                        awayScoreController,
                        'Away Score',
                        Icons.looks_two_rounded,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),

                _dialogField(
                  dateController,
                  'Date',
                  Icons.calendar_today_rounded,
                ),

                _dialogField(
                  venueController,
                  'Venue',
                  Icons.location_on_outlined,
                ),
              ],
            ),
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                setState(() {
                  results[index] = {
                    'sport': sportController.text.trim(),
                    'home': homeController.text.trim(),
                    'away': awayController.text.trim(),
                    'homeScore':
                        homeScoreController.text.trim(),
                    'awayScore':
                        awayScoreController.text.trim(),
                    'date': dateController.text.trim(),
                    'venue': venueController.text.trim(),
                  };
                });

                Navigator.pop(context);
              },
              child: const Text('Save Changes'),
            ),
          ],
        );
      },
    );
  }

  Widget _dialogField(
    TextEditingController controller,
    String label,
    IconData icon, {
    TextInputType? keyboardType,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  void _deleteResult(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Delete Result?',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: const Text(
            'This result will be removed from the admin list.',
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            TextButton(
              onPressed: () {
                setState(() {
                  results.removeAt(index);
                });

                Navigator.pop(context);
              },
              child: const Text(
                'Delete',
                style: TextStyle(
                  color: Colors.red,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}