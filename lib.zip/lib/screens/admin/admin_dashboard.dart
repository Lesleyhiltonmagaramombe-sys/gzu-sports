import 'package:flutter/material.dart';
import 'manage_fixtures.dart';
import 'manage_results.dart';
import 'manage_teams.dart';
import 'announcements.dart';
import 'manage_notifications.dart';
import '../login_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),

      appBar: AppBar(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Admin Dashboard',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
        
actions: [
  IconButton(
    tooltip: 'Notifications',
    onPressed: () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const ManageNotifications(),
        ),
      );
    },
    icon: const Icon(
      Icons.notifications_none_rounded,
    ),
  ),
  IconButton(
    tooltip: 'Log out',
    onPressed: () {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (context) => const LoginScreen(),
        ),
        (route) => false,
      );
    },
    icon: const Icon(
      Icons.logout_rounded,
    ),
  ),
  const SizedBox(width: 8),
],

      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            20,
            20,
            20,
            30,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              const Text(
                'Welcome back, Admin',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF141B16),
                ),
              ),

              const SizedBox(height: 6),

              const Text(
                'Manage GZU Sports Hub from one place.',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF68716B),
                ),
              ),

              const SizedBox(height: 24),

              Row(
                children: [
                  Expanded(
                    child: _statCard(
                      icon: Icons.event_rounded,
                      value: '12',
                      label: 'Fixtures',
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: _statCard(
                      icon: Icons.emoji_events_rounded,
                      value: '18',
                      label: 'Results',
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: _statCard(
                      icon: Icons.groups_rounded,
                      value: '6',
                      label: 'Teams',
                    ),
                  ),

                  const SizedBox(width: 12),

                  Expanded(
                    child: _statCard(
                      icon: Icons.campaign_rounded,
                      value: '4',
                      label: 'Updates',
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 30),

              const Text(
                'Management',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF141B16),
                ),
              ),

              const SizedBox(height: 14),

              // MANAGE FIXTURES
              _adminOption(
                context,
                icon: Icons.calendar_month_rounded,
                title: 'Manage Fixtures',
                subtitle:
                    'Add, edit and publish upcoming fixtures.',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const ManageFixtures(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // MANAGE RESULTS
              _adminOption(
                context,
                icon: Icons.scoreboard_rounded,
                title: 'Manage Results',
                subtitle:
                    'Record match scores and update results.',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const ManageResults(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // MANAGE TEAMS
              _adminOption(
                context,
                icon: Icons.groups_rounded,
                title: 'Manage Teams',
                subtitle:
                    'Create and manage university sports teams.',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const ManageTeams(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // ANNOUNCEMENTS
              _adminOption(
                context,
                icon: Icons.campaign_rounded,
                title: 'Announcements',
                subtitle:
                    'Publish important sports department updates.',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const Announcements(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 12),

              // NOTIFICATIONS
              _adminOption(
                context,
                icon: Icons.notifications_active_rounded,
                title: 'Notifications',
                subtitle:
                    'Send updates and match reminders to users.',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const ManageNotifications(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 30),

              // SYSTEM STATUS
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.circular(18),
                  border: Border.all(
                    color: const Color(0xFFE1E6E2),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: const Color(0xFFE7F5EC),
                        borderRadius:
                            BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.check_circle_rounded,
                        color: Color(0xFF1B7A47),
                      ),
                    ),

                    const SizedBox(width: 14),

                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            'System Status',
                            style: TextStyle(
                              fontWeight:
                                  FontWeight.w700,
                              fontSize: 15,
                              color:
                                  Color(0xFF141B16),
                            ),
                          ),

                          SizedBox(height: 3),

                          Text(
                            'Sports Hub is currently operational.',
                            style: TextStyle(
                              fontSize: 12,
                              color:
                                  Color(0xFF68716B),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const Text(
                      'ONLINE',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF1B7A47),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Widget _statCard({
    required IconData icon,
    required String value,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: const Color(0xFFE1E6E2),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFFE8F3EC),
              borderRadius:
                  BorderRadius.circular(12),
            ),
            child: Icon(
              icon,
              color: const Color(0xFF0F3D24),
              size: 21,
            ),
          ),

          const SizedBox(width: 12),

          Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF141B16),
                ),
              ),

              Text(
                label,
                style: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFF68716B),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  static Widget _adminOption(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(
            borderRadius:
                BorderRadius.circular(18),
            border: Border.all(
              color: const Color(0xFFE1E6E2),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFF0F3D24),
                  borderRadius:
                      BorderRadius.circular(14),
                ),
                child: Icon(
                  icon,
                  color: const Color(0xFFB8FF3C),
                  size: 23,
                ),
              ),

              const SizedBox(width: 15),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight:
                            FontWeight.w700,
                        color:
                            Color(0xFF141B16),
                      ),
                    ),

                    const SizedBox(height: 4),

                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 12,
                        color:
                            Color(0xFF68716B),
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),

              const Icon(
                Icons.chevron_right_rounded,
                color: Color(0xFF9AA39D),
              ),
            ],
          ),
        ),
      ),
    );
  }
}