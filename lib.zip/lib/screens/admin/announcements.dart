import 'package:flutter/material.dart';

class Announcements extends StatefulWidget {
  const Announcements({super.key});

  @override
  State<Announcements> createState() => _AnnouncementsState();
}

class _AnnouncementsState extends State<Announcements> {
  final List<Map<String, String>> announcements = [
    {
      'category': 'Sports Department',
      'title': 'Welcome to GZU Sports Hub',
      'message':
          'Stay updated with fixtures, results, teams and important sports information.',
      'date': 'Today',
    },
    {
      'category': 'Rugby',
      'title': 'Rugby Training Reminder',
      'message':
          'All rugby players are reminded to attend the next scheduled training session.',
      'date': 'Yesterday',
    },
    {
      'category': 'Football',
      'title': 'Football Results Updated',
      'message':
          'The latest football match results are now available on the Sports Hub.',
      'date': '02 Sep 2026',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),

      appBar: AppBar(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Announcements',
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: const Color(0xFFB8FF3C),
        onPressed: () {
          _showAddAnnouncementDialog(context);
        },
        child: const Icon(Icons.add_rounded),
      ),

      body: announcements.isEmpty
          ? _emptyState()
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
              itemCount: announcements.length,
              itemBuilder: (context, index) {
                return _announcementCard(
                  announcements[index],
                  index,
                );
              },
            ),
    );
  }

  Widget _announcementCard(
    Map<String, String> announcement,
    int index,
  ) {
    final category = announcement['category'] ?? '';
    final title = announcement['title'] ?? '';
    final message = announcement['message'] ?? '';
    final date = announcement['date'] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: const Color(0xFFE1E6E2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFF0F3D24),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: const Icon(
                  Icons.campaign_rounded,
                  color: Color(0xFFB8FF3C),
                  size: 22,
                ),
              ),

              const SizedBox(width: 12),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      category,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1B7A47),
                      ),
                    ),

                    const SizedBox(height: 3),

                    Text(
                      date,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFF9AA39D),
                      ),
                    ),
                  ],
                ),
              ),

              PopupMenuButton<String>(
                icon: const Icon(
                  Icons.more_vert_rounded,
                  color: Color(0xFF68716B),
                ),
                onSelected: (value) {
                  if (value == 'edit') {
                    _showEditAnnouncementDialog(
                      context,
                      index,
                    );
                  }

                  if (value == 'delete') {
                    _deleteAnnouncement(index);
                  }
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'edit',
                    child: Text('Edit announcement'),
                  ),
                  PopupMenuItem(
                    value: 'delete',
                    child: Text('Delete announcement'),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 16),

          Text(
            title,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w800,
              color: Color(0xFF141B16),
            ),
          ),

          const SizedBox(height: 7),

          Text(
            message,
            style: const TextStyle(
              fontSize: 13,
              height: 1.45,
              color: Color(0xFF68716B),
            ),
          ),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3EC),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.campaign_rounded,
                size: 34,
                color: Color(0xFF0F3D24),
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'No announcements yet',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w800,
                color: Color(0xFF141B16),
              ),
            ),

            const SizedBox(height: 7),

            const Text(
              'Create an announcement using the + button.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF68716B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddAnnouncementDialog(BuildContext context) {
    final categoryController = TextEditingController();
    final titleController = TextEditingController();
    final messageController = TextEditingController();
    final dateController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Add Announcement',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(
                  categoryController,
                  'Category',
                  Icons.category_rounded,
                ),

                _dialogField(
                  titleController,
                  'Title',
                  Icons.title_rounded,
                ),

                _dialogField(
                  messageController,
                  'Message',
                  Icons.message_rounded,
                  maxLines: 4,
                ),

                _dialogField(
                  dateController,
                  'Date',
                  Icons.calendar_today_rounded,
                ),
              ],
            ),
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                if (categoryController.text.trim().isEmpty ||
                    titleController.text.trim().isEmpty ||
                    messageController.text.trim().isEmpty) {
                  return;
                }

                setState(() {
                  announcements.add({
                    'category': categoryController.text.trim(),
                    'title': titleController.text.trim(),
                    'message': messageController.text.trim(),
                    'date': dateController.text.trim().isEmpty
                        ? 'Today'
                        : dateController.text.trim(),
                  });
                });

                Navigator.pop(context);
              },
              child: const Text('Publish'),
            ),
          ],
        );
      },
    );
  }

  void _showEditAnnouncementDialog(
    BuildContext context,
    int index,
  ) {
    final announcement = announcements[index];

    final categoryController = TextEditingController(
      text: announcement['category'],
    );

    final titleController = TextEditingController(
      text: announcement['title'],
    );

    final messageController = TextEditingController(
      text: announcement['message'],
    );

    final dateController = TextEditingController(
      text: announcement['date'],
    );

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Edit Announcement',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _dialogField(
                  categoryController,
                  'Category',
                  Icons.category_rounded,
                ),

                _dialogField(
                  titleController,
                  'Title',
                  Icons.title_rounded,
                ),

                _dialogField(
                  messageController,
                  'Message',
                  Icons.message_rounded,
                  maxLines: 4,
                ),

                _dialogField(
                  dateController,
                  'Date',
                  Icons.calendar_today_rounded,
                ),
              ],
            ),
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                if (categoryController.text.trim().isEmpty ||
                    titleController.text.trim().isEmpty ||
                    messageController.text.trim().isEmpty) {
                  return;
                }

                setState(() {
                  announcements[index] = {
                    'category': categoryController.text.trim(),
                    'title': titleController.text.trim(),
                    'message': messageController.text.trim(),
                    'date': dateController.text.trim().isEmpty
                        ? 'Today'
                        : dateController.text.trim(),
                  };
                });

                Navigator.pop(context);
              },
              child: const Text('Save Changes'),
            ),
          ],
        );
      },
    );
  }

  Widget _dialogField(
    TextEditingController controller,
    String label,
    IconData icon, {
    int maxLines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: maxLines == 1
              ? Icon(icon)
              : const Padding(
                  padding: EdgeInsets.only(bottom: 65),
                  child: Icon(Icons.message_rounded),
                ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  void _deleteAnnouncement(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Delete Announcement?',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),

          content: const Text(
            'This announcement will be removed from the admin list.',
          ),

          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),

            TextButton(
              onPressed: () {
                setState(() {
                  announcements.removeAt(index);
                });

                Navigator.pop(context);
              },
              child: const Text(
                'Delete',
                style: TextStyle(
                  color: Colors.red,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}