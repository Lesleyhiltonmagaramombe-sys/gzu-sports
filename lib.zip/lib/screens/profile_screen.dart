
import 'package:flutter/material.dart';
import 'login_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool notificationsEnabled = true;
  String favouriteSport = 'Rugby';

  final List<String> sports = [
    'Rugby',
    'Football',
    'Basketball',
    'Netball',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F7F3),

      // FIXED: AppBar must be assigned to the appBar property.
      appBar: AppBar(
        backgroundColor: const Color(0xFFF4F7F3),
        elevation: 0,
        scrolledUnderElevation: 0,
        title: const Text(
          'Profile',
          style: TextStyle(
            color: Color(0xFF10160F),
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),

      body: SafeArea(
        child: ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 35),
          children: [
            _profileHeader(),

            const SizedBox(height: 22),
            _sectionTitle('My Sports'),
            const SizedBox(height: 10),

            _card(
              children: [
                _row(
                  Icons.sports_rounded,
                  'Favourite sport',
                  favouriteSport,
                  onTap: _chooseSport,
                ),
                _divider(),
                _row(
                  Icons.groups_rounded,
                  'Favourite team',
                  'Mashava',
                  onTap: () => _message(
                    'Team selection will be connected to the database later.',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 22),
            _sectionTitle('Preferences'),
            const SizedBox(height: 10),

            _card(
              children: [
                _row(
                  Icons.notifications_none_rounded,
                  'Sports notifications',
                  notificationsEnabled
                      ? 'Fixture and result alerts enabled'
                      : 'Notifications are turned off',
                  trailing: Switch.adaptive(
                    value: notificationsEnabled,
                    activeTrackColor: const Color(0xFF1E9553),
                    activeThumbColor: const Color(0xFFC6FF4D),
                    onChanged: (value) {
                      setState(() {
                        notificationsEnabled = value;
                      });
                    },
                  ),
                ),
                _divider(),
                _row(
                  Icons.language_rounded,
                  'Language',
                  'English',
                  onTap: () => _message(
                    'English is currently available.',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 22),
            _sectionTitle('About'),
            const SizedBox(height: 10),

            _card(
              children: [
                _row(
                  Icons.info_outline_rounded,
                  'About GZU Sports Hub',
                  'University sports information platform',
                  onTap: _showAbout,
                ),
                _divider(),
                _row(
                  Icons.privacy_tip_outlined,
                  'Privacy',
                  'Account and sports preferences',
                  onTap: () => _message(
                    'Privacy controls will be connected with authentication later.',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Logout returns to LoginScreen and clears previous screens.
            OutlinedButton.icon(
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(
                    builder: (context) => const LoginScreen(),
                  ),
                  (route) => false,
                );
              },
              icon: const Icon(
                Icons.logout_rounded,
                size: 19,
              ),
              label: const Text(
                'Log out',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFB24D43),
                side: const BorderSide(
                  color: Color(0xFFE7C7C3),
                ),
                minimumSize: const Size.fromHeight(52),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(17),
                ),
              ),
            ),

            const SizedBox(height: 18),

            const Center(
              child: Text(
                'GZU SPORTS HUB  •  VERSION 1.0.0',
                style: TextStyle(
                  color: Color(0xFF9AA398),
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _profileHeader() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: const Color(0xFF0B2E1C),
        borderRadius: BorderRadius.circular(26),
      ),
      child: Row(
        children: [
          Container(
            width: 68,
            height: 68,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: const Color(0xFFC6FF4D),
              borderRadius: BorderRadius.circular(21),
            ),
            child: const Text(
              'LM',
              style: TextStyle(
                color: Color(0xFF0B2E1C),
                fontSize: 22,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),

          const SizedBox(width: 16),

          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Lesley Magaramombe',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'GZU Student',
                  style: TextStyle(
                    color: Color(0xFFD7E1D8),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 9),
                Row(
                  children: [
                    Icon(
                      Icons.verified_outlined,
                      size: 15,
                      color: Color(0xFFC6FF4D),
                    ),
                    SizedBox(width: 5),
                    Text(
                      'Sports Hub Member',
                      style: TextStyle(
                        color: Color(0xFFC6FF4D),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF10160F),
        fontSize: 17,
        fontWeight: FontWeight.w800,
      ),
    );
  }

  Widget _card({required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: const Color(0xFFE6EAE1),
        ),
      ),
      child: Column(
        children: children,
      ),
    );
  }

  Widget _divider() {
    return Container(
      height: 1,
      color: const Color(0xFFE6EAE1),
    );
  }

  Widget _row(
    IconData icon,
    String title,
    String subtitle, {
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 12,
            horizontal: 2,
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xFFE4FFB0),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  icon,
                  color: const Color(0xFF0B2E1C),
                  size: 21,
                ),
              ),

              const SizedBox(width: 13),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Color(0xFF10160F),
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF7A847B),
                        fontSize: 11,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),

              trailing ??
                  const Icon(
                    Icons.arrow_forward_ios_rounded,
                    size: 15,
                    color: Color(0xFF9AA398),
                  ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _chooseSport() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Favourite sport',
                style: TextStyle(
                  color: Color(0xFF10160F),
                  fontSize: 21,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Choose the sport you follow most.',
                style: TextStyle(
                  color: Color(0xFF6C766A),
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 12),

              ...sports.map(
                (sport) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    sport == favouriteSport
                        ? Icons.check_circle_rounded
                        : Icons.circle_outlined,
                    color: sport == favouriteSport
                        ? const Color(0xFF1E9553)
                        : const Color(0xFF9AA398),
                  ),
                  title: Text(
                    sport,
                    style: const TextStyle(
                      color: Color(0xFF10160F),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  onTap: () => Navigator.pop(context, sport),
                ),
              ),
            ],
          ),
        );
      },
    );

    if (selected != null && mounted) {
      setState(() {
        favouriteSport = selected;
      });
    }
  }

  void _showAbout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text(
          'GZU Sports Hub',
          style: TextStyle(
            color: Color(0xFF10160F),
            fontWeight: FontWeight.w800,
          ),
        ),
        content: const Text(
          'A mobile-based platform for GZU sports fixtures, results, standings, teams and announcements.',
          style: TextStyle(
            color: Color(0xFF6C766A),
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Close',
              style: TextStyle(
                color: Color(0xFF0B2E1C),
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _message(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF0B2E1C),
      ),
    );
  }
}
