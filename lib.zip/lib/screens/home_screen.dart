

import 'package:flutter/material.dart';

import 'fixtures_screen.dart';
import 'results_screen.dart';
import 'standings_screen.dart';
import 'teams_screen.dart';
import 'updates_screen.dart';
import 'notifications_screen.dart';
import 'profile_screen.dart';

// ============================================================
// APP COLORS — unchanged, GZU green + lime
// ============================================================

class AppColors {
  static const Color primary = Color(0xFF0F3D24);
  static const Color primaryLight = Color(0xFF1B7A47);
  static const Color accent = Color(0xFFB8FF3C);

  static const Color bg = Color(0xFFF6F7F5);
  static const Color ink = Color(0xFF141B16);

  static const Color muted = Color(0xFF6E756F);
  static const Color border = Color(0xFFE2E6E2);

  static const Color white = Colors.white;
}

// ============================================================
// HOME SCREEN
// ============================================================

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  final List<Widget> _screens = const [
    HomeContent(),
    FixturesScreen(),
    ResultsScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      extendBody: true,
      body: Stack(
        children: [
          // faint field-marking texture behind everything — a
          // nod to a pitch, not a generic blurred blob.
          const Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: _PitchLinesPainter()),
            ),
          ),
          SafeArea(
            bottom: false,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 320),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (child, anim) {
                return FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, 0.03),
                      end: Offset.zero,
                    ).animate(anim),
                    child: child,
                  ),
                );
              },
              child: KeyedSubtree(
                key: ValueKey(selectedIndex),
                child: _screens[selectedIndex],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: FloatingNavBar(
        selectedIndex: selectedIndex,
        onSelect: (i) => setState(() => selectedIndex = i),
      ),
    );
  }
}

/// Very faint dotted halfway-line + centre-circle motif, drawn once
/// in the corner of the screen. Reads as texture, not decoration.
class _PitchLinesPainter extends CustomPainter {
  const _PitchLinesPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.primary.withValues(alpha: 0.035)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    final cx = size.width * 0.86;
    const cy = -40.0;
    canvas.drawCircle(Offset(cx, cy), 130, paint);
    canvas.drawCircle(Offset(cx, cy), 2, paint..style = PaintingStyle.fill);

    final dashPaint = Paint()
      ..color = AppColors.primary.withValues(alpha: 0.05)
      ..strokeWidth = 1.2;
    double y = 210;
    while (y < 340) {
      canvas.drawLine(Offset(size.width - 26, y), Offset(size.width - 26, y + 10), dashPaint);
      y += 18;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ============================================================
// FLOATING NAVIGATION BAR
// ============================================================

class FloatingNavBar extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  const FloatingNavBar({
    super.key,
    required this.selectedIndex,
    required this.onSelect,
  });

  static const _items = [
    (Icons.home_rounded, 'Home'),
    (Icons.calendar_month_rounded, 'Fixtures'),
    (Icons.emoji_events_rounded, 'Results'),
    (Icons.person_rounded, 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 14),
        child: Container(
          height: 64,
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            color: AppColors.ink,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: AppColors.ink.withValues(alpha: 0.28),
                blurRadius: 22,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Stack(
            children: [
              AnimatedAlign(
                duration: const Duration(milliseconds: 280),
                curve: Curves.easeOutCubic,
                alignment: Alignment(
                  -1 + (selectedIndex * (2 / (_items.length - 1))),
                  0,
                ),
                child: FractionallySizedBox(
                  widthFactor: 1 / _items.length,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    decoration: BoxDecoration(
                      color: AppColors.accent,
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                ),
              ),
              Row(
                children: List.generate(_items.length, (i) {
                  final selected = i == selectedIndex;
                  final item = _items[i];
                  return Expanded(
                    child: InkWell(
                      onTap: () => onSelect(i),
                      borderRadius: BorderRadius.circular(15),
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 200),
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.2,
                          color: selected ? AppColors.ink : Colors.white60,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              item.$1,
                              size: 20,
                              color: selected ? AppColors.ink : Colors.white60,
                            ),
                            const SizedBox(height: 3),
                            Text(item.$2),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// HOME CONTENT
// ============================================================

class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: AppColors.primary,
      onRefresh: () async {
        await Future.delayed(const Duration(milliseconds: 700));
      },
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 120),
        children: [
          // --------------------------------------------------
          // HEADER — crest mark + wordmark instead of a
          // generic "welcome back" banner
          // --------------------------------------------------
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const _CrestMark(),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'GZU SPORTS',
                      style: TextStyle(
                        fontSize: 11,
                        letterSpacing: 2.4,
                        fontWeight: FontWeight.w800,
                        color: AppColors.muted,
                      ),
                    ),
                    const SizedBox(height: 3),
                    const Text(
                      'Lesley',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.6,
                        height: 1.05,
                        color: AppColors.ink,
                      ),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const NotificationsScreen()),
                ),
                child: Container(
                  width: 44,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.ink,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      const Icon(
                        Icons.notifications_none_rounded,
                        size: 22,
                        color: Colors.white,
                      ),
                      Positioned(
                        top: 9,
                        right: 9,
                        child: Container(
                          width: 7,
                          height: 7,
                          decoration: const BoxDecoration(
                            color: AppColors.accent,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 26),

          // --------------------------------------------------
          // NEXT FIXTURE — matchday ticket
          // --------------------------------------------------
          const SectionTitle(index: '01', title: 'Next fixture', action: 'View all'),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FixturesScreen()),
            ),
            child: const _MatchTicket(),
          ),

          const SizedBox(height: 28),

          // --------------------------------------------------
          // QUICK ACCESS — bento grid, checkerboard tiles
          // --------------------------------------------------
          const SectionTitle(index: '02', title: 'Quick access'),
          const SizedBox(height: 12),
          _BentoAction(
            icon: Icons.calendar_month_rounded,
            title: 'Fixtures',
            subtitle: 'See every upcoming game on the calendar',
            dark: true,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FixturesScreen()),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: QuickAction(
                  icon: Icons.emoji_events_rounded,
                  title: 'Results',
                  subtitle: 'Recent',
                  onTap: (context) => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ResultsScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: QuickAction(
                  icon: Icons.table_chart_rounded,
                  title: 'Standings',
                  subtitle: 'League',
                  onTap: (context) => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const StandingsScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: QuickAction(
                  icon: Icons.groups_rounded,
                  title: 'Teams',
                  subtitle: 'Explore',
                  onTap: (context) => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const TeamsScreen()),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 28),

          // --------------------------------------------------
          // PERFORMANCE — scoreboard panel
          // --------------------------------------------------
          const SectionTitle(index: '03', title: 'Season performance'),
          const SizedBox(height: 12),
          const _Scoreboard(),

          const SizedBox(height: 28),

          // --------------------------------------------------
          // LATEST RESULT
          // --------------------------------------------------
          SectionTitle(
            index: '04',
            title: 'Latest result',
            action: 'View all',
            onAction: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ResultsScreen()),
            ),
          ),
          const SizedBox(height: 12),
          const ResultCard(),

          const SizedBox(height: 28),

          // --------------------------------------------------
          // LATEST UPDATES
          // --------------------------------------------------
          SectionTitle(
            index: '05',
            title: 'Latest updates',
            action: 'See all',
            onAction: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UpdatesScreen()),
            ),
          ),
          const SizedBox(height: 12),
          _UpdatePreviewCard(
            icon: Icons.campaign_rounded,
            category: 'SPORTS DEPARTMENT',
            title: 'Welcome to GZU Sports Hub',
            time: 'Today',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UpdatesScreen()),
            ),
          ),
          const SizedBox(height: 10),
          _UpdatePreviewCard(
            icon: Icons.sports_rugby_rounded,
            category: 'RUGBY',
            title: 'Rugby Fixture Confirmed',
            time: 'Today',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const UpdatesScreen()),
            ),
          ),

          const SizedBox(height: 34),

          // --------------------------------------------------
          // FOOTER
          // --------------------------------------------------
          const Center(
            child: Column(
              children: [
                _CrestMark(size: 40),
                SizedBox(height: 10),
                Text(
                  'GREAT ZIMBABWE UNIVERSITY',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.6,
                    color: AppColors.ink,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  'Sports Hub',
                  style: TextStyle(fontSize: 11, color: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// A hexagonal crest badge, standing in for a club/university crest.
/// Reused in the header and footer so the brand feels considered,
/// not a stock icon.
class _CrestMark extends StatelessWidget {
  final double size;
  const _CrestMark({this.size = 42});

  @override
  Widget build(BuildContext context) {
    return ClipPath(
      clipper: _HexClipper(),
      child: Container(
        width: size,
        height: size,
        color: AppColors.primary,
        alignment: Alignment.center,
        child: Text(
          'GZU',
          style: TextStyle(
            color: AppColors.accent,
            fontSize: size * 0.26,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.2,
          ),
        ),
      ),
    );
  }
}

class _HexClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final w = size.width;
    final h = size.height;
    final path = Path();
    path.moveTo(w * 0.5, 0);
    path.lineTo(w, h * 0.25);
    path.lineTo(w, h * 0.75);
    path.lineTo(w * 0.5, h);
    path.lineTo(0, h * 0.75);
    path.lineTo(0, h * 0.25);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

// ============================================================
// MATCH TICKET — replaces the plain gradient fixture card
// ============================================================

class _MatchTicket extends StatelessWidget {
  const _MatchTicket();

  @override
  Widget build(BuildContext context) {
    return ClipPath(
      clipper: _TicketClipper(),
      child: Container(
        color: AppColors.primary,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white24),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text(
                          'RUGBY · FIXTURE',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 9,
                            letterSpacing: 1.4,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      const Spacer(),
                      const Text(
                        'KICKS OFF IN 9 DAYS',
                        style: TextStyle(
                          color: AppColors.accent,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: Team(name: 'Mashava', alignment: CrossAxisAlignment.start),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: _VsBadge(),
                      ),
                      Expanded(
                        child: Team(name: 'City Campus', alignment: CrossAxisAlignment.end),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            CustomPaint(
              size: const Size(double.infinity, 1),
              painter: _DashedLinePainter(),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
              child: Row(
                children: const [
                  Expanded(child: _MetaPill(icon: Icons.calendar_today_rounded, text: 'Sat 12 Sep')),
                  SizedBox(width: 8),
                  Expanded(child: _MetaPill(icon: Icons.access_time_rounded, text: '15:00')),
                  SizedBox(width: 8),
                  Expanded(child: _MetaPill(icon: Icons.location_on_outlined, text: 'Primary Field')),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Cuts a small semicircular notch out of each side, at the same
/// height as the dashed perforation, so the card reads as a torn
/// ticket rather than a rounded rectangle.
class _TicketClipper extends CustomClipper<Path> {
  static const double _notchY = 116;
  static const double _r = 11;
  static const double _radius = 22;

  @override
  Path getClip(Size size) {
    final w = size.width;
    final h = size.height;
    final path = Path()
      ..moveTo(_radius, 0)
      ..lineTo(w - _radius, 0)
      ..quadraticBezierTo(w, 0, w, _radius)
      ..lineTo(w, _notchY - _r)
      ..arcToPoint(Offset(w, _notchY + _r), radius: const Radius.circular(_r), clockwise: false)
      ..lineTo(w, h - _radius)
      ..quadraticBezierTo(w, h, w - _radius, h)
      ..lineTo(_radius, h)
      ..quadraticBezierTo(0, h, 0, h - _radius)
      ..lineTo(0, _notchY + _r)
      ..arcToPoint(Offset(0, _notchY - _r), radius: const Radius.circular(_r), clockwise: false)
      ..lineTo(0, _radius)
      ..quadraticBezierTo(0, 0, _radius, 0)
      ..close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

class _DashedLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.18)
      ..strokeWidth = 1.4;
    const dash = 6.0;
    const gap = 5.0;
    double x = 20;
    final y = size.height / 2;
    while (x < size.width - 20) {
      canvas.drawLine(Offset(x, y), Offset(x + dash, y), paint);
      x += dash + gap;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _VsBadge extends StatelessWidget {
  const _VsBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: AppColors.accent,
        shape: BoxShape.circle,
      ),
      alignment: Alignment.center,
      child: const Text(
        'VS',
        style: TextStyle(
          color: AppColors.primary,
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 0.4,
        ),
      ),
    );
  }
}

class _MetaPill extends StatelessWidget {
  final IconData icon;
  final String text;

  const _MetaPill({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(11),
      ),
      child: Row(
        children: [
          Icon(icon, size: 13, color: Colors.white.withValues(alpha: 0.75)),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.9),
                fontSize: 10,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// BENTO ACTION — the wide featured quick-access tile
// ============================================================

class _BentoAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool dark;
  final VoidCallback onTap;

  const _BentoAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.dark = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.fromLTRB(18, 16, 16, 16),
        decoration: BoxDecoration(
          color: dark ? AppColors.primary : AppColors.white,
          borderRadius: BorderRadius.circular(20),
          border: dark ? null : Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: dark ? AppColors.accent : AppColors.primary.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, size: 22, color: dark ? AppColors.primary : AppColors.primary),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: dark ? Colors.white : AppColors.ink,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: dark ? Colors.white60 : AppColors.muted,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_outward_rounded,
              size: 18,
              color: dark ? AppColors.accent : AppColors.muted,
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SCOREBOARD — replaces the plain stats row
// ============================================================

class _Scoreboard extends StatelessWidget {
  const _Scoreboard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
      decoration: BoxDecoration(
        color: AppColors.ink,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        children: [
          const Row(
            children: [
              Expanded(child: _ScoreDigit(value: '14', label: 'WINS')),
              _ScoreboardDivider(),
              Expanded(child: _ScoreDigit(value: '03', label: 'DRAWS')),
              _ScoreboardDivider(),
              Expanded(child: _ScoreDigit(value: '05', label: 'LOSSES')),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: SizedBox(
              height: 5,
              child: Row(
                children: [
                  Expanded(flex: 14, child: Container(color: AppColors.accent)),
                  Expanded(flex: 3, child: Container(color: Colors.white38)),
                  Expanded(flex: 5, child: Container(color: Colors.white12)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScoreDigit extends StatelessWidget {
  final String value;
  final String label;
  const _ScoreDigit({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontFeatures: [FontFeature.tabularFigures()],
            letterSpacing: -0.5,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
            color: Colors.white38,
          ),
        ),
      ],
    );
  }
}

class _ScoreboardDivider extends StatelessWidget {
  const _ScoreboardDivider();

  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 34, color: Colors.white12);
  }
}

// ============================================================
// RESULT CARD
// ============================================================

class ResultCard extends StatelessWidget {
  const ResultCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 6,
                height: 6,
                margin: const EdgeInsets.only(right: 8),
                decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
              ),
              const Text(
                'RUGBY',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.1,
                  color: AppColors.ink,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  borderRadius: BorderRadius.circular(7),
                ),
                child: const Text(
                  'WON',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                    color: AppColors.primary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const _ScoreRow(),
        ],
      ),
    );
  }
}

class _ScoreRow extends StatelessWidget {
  const _ScoreRow();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            children: const [
              _CrestAvatar(name: 'Mashava'),
              SizedBox(height: 8),
              Text(
                'Mashava',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.ink),
              ),
            ],
          ),
        ),
        Column(
          children: [
            const Text(
              '24 – 12',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w900,
                color: AppColors.ink,
                letterSpacing: -0.5,
                fontFeatures: [FontFeature.tabularFigures()],
              ),
            ),
            const SizedBox(height: 3),
            Text(
              '05 Sep 2026',
              style: TextStyle(fontSize: 11, color: AppColors.muted, fontWeight: FontWeight.w500),
            ),
          ],
        ),
        Expanded(
          child: Column(
            children: const [
              _CrestAvatar(name: 'City Campus'),
              SizedBox(height: 8),
              Text(
                'City Campus',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.ink),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ============================================================
// SECTION TITLE — numbered tag instead of a bare heading
// ============================================================

class SectionTitle extends StatelessWidget {
  final String title;
  final String? index;
  final String? action;
  final VoidCallback? onAction;

  const SectionTitle({
    super.key,
    required this.title,
    this.index,
    this.action,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (index != null) ...[
          Container(
            width: 22,
            height: 22,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              index!,
              style: const TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w800,
                color: AppColors.accent,
              ),
            ),
          ),
          const SizedBox(width: 9),
        ],
        Text(
          title,
          style: const TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.2,
            color: AppColors.ink,
          ),
        ),
        const Spacer(),
        if (action != null)
          GestureDetector(
            onTap: onAction,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 2),
              decoration: const BoxDecoration(
                border: Border(
            
                bottom: BorderSide(color: AppColors.primary, width: 1.4),
              ),
              ),
              child: Text(
                action!,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: AppColors.primary,
                ),
              ),
            ),
          ),
      ],
    );
  }
}

// ============================================================
// TEAM
// ============================================================

class Team extends StatelessWidget {
  final String name;
  final CrossAxisAlignment alignment;

  const Team({super.key, required this.name, required this.alignment});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: alignment,
      children: [
        _CrestAvatar(name: name, dark: true),
        const SizedBox(height: 9),
        Text(
          name,
          textAlign: alignment == CrossAxisAlignment.end ? TextAlign.right : TextAlign.left,
          style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800),
        ),
      ],
    );
  }
}

// ============================================================
// CREST AVATAR — hexagonal team badge instead of a round
// initials bubble
// ============================================================

class _CrestAvatar extends StatelessWidget {
  final String name;
  final bool dark;

  const _CrestAvatar({required this.name, this.dark = false});

  String _initials(String name) {
    final clean = name.trim();
    if (clean.isEmpty) return '?';
    final parts = clean.split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.length >= 2) return parts.take(2).map((p) => p[0]).join().toUpperCase();
    if (clean.length <= 3) return clean.toUpperCase();
    return clean.substring(0, 3).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    return ClipPath(
      clipper: _HexClipper(),
      child: Container(
        width: 44,
        height: 44,
        color: dark ? Colors.white.withValues(alpha: 0.12) : AppColors.primary.withValues(alpha: 0.08),
        alignment: Alignment.center,
        child: Text(
          _initials(name),
          style: TextStyle(
            color: dark ? Colors.white : AppColors.primary,
            fontSize: 12,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }
}

// ============================================================
// QUICK ACTION — used for the small tiles under the bento hero
// ============================================================

class QuickAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final void Function(BuildContext context) onTap;

  const QuickAction({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onTap(context),
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: [
            Icon(icon, size: 20, color: AppColors.primary),
            const SizedBox(height: 8),
            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.ink),
            ),
            const SizedBox(height: 1),
            Text(
              subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 9.5, color: AppColors.muted, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// UPDATE PREVIEW CARD
// ============================================================

class _UpdatePreviewCard extends StatelessWidget {
  final IconData icon;
  final String category;
  final String title;
  final String time;
  final VoidCallback onTap;

  const _UpdatePreviewCard({
    required this.icon,
    required this.category,
    required this.title,
    required this.time,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(11),
              ),
              child: Icon(icon, size: 18, color: AppColors.primary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    category,
                    style: const TextStyle(
                      fontSize: 9,
                      letterSpacing: 1.0,
                      fontWeight: FontWeight.w800,
                      color: AppColors.primaryLight,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.ink),
                  ),
                  const SizedBox(height: 3),
                  Text(time, style: const TextStyle(fontSize: 10, color: AppColors.muted)),
                ],
              ),
            ),
            const Icon(Icons.arrow_outward_rounded, color: AppColors.muted, size: 16),
          ],
        ),
      ),
    );
  }
}