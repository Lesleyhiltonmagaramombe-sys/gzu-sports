import 'package:flutter/material.dart';

class StandingsScreen extends StatefulWidget {
  const StandingsScreen({super.key});

  @override
  State<StandingsScreen> createState() => _StandingsScreenState();
}

class _StandingsScreenState extends State<StandingsScreen> {
  String selectedSport = 'Rugby';

  final List<String> sports = [
    'Rugby',
    'Football',
    'Basketball',
    'Netball',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 110),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // HEADER
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          'GZU SPORTS',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2,
                            color: Color(0xFF1B7A47),
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          'Standings',
                          style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.7,
                            color: Color(0xFF141B16),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: const Color(0xFFE9EBE6),
                      ),
                    ),
                    child: const Icon(
                      Icons.emoji_events_outlined,
                      color: Color(0xFF141B16),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 26),

              // SPORT SELECTOR
              SizedBox(
                height: 42,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: sports.map((sport) {
                    final selected = selectedSport == sport;

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedSport = sport;
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: selected
                              ? const Color(0xFF0F3D24)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: selected
                                ? const Color(0xFF0F3D24)
                                : const Color(0xFFE9EBE6),
                          ),
                        ),
                        child: Text(
                          sport,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: selected
                                ? Colors.white
                                : const Color(0xFF6E766F),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),

              const SizedBox(height: 30),

              // SEASON INFO
              Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '2026 SEASON',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.5,
                            color: Color(0xFF6E766F),
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          'League Table',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF141B16),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEAF3ED),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'LIVE TABLE',
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                        color: Color(0xFF0F3D24),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // TABLE
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: const Color(0xFFE9EBE6),
                  ),
                ),
                child: Column(
                  children: [
                    // TABLE HEADER
                    Container(
                      padding: const EdgeInsets.fromLTRB(
                        16,
                        15,
                        16,
                        15,
                      ),
                      decoration: const BoxDecoration(
                        color: Color(0xFFF2F4F1),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(22),
                          topRight: Radius.circular(22),
                        ),
                      ),
                      child: const Row(
                        children: [
                          SizedBox(
                            width: 30,
                            child: Text(
                              'POS',
                              style: _headerStyle,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              'TEAM',
                              style: _headerStyle,
                            ),
                          ),
                          SizedBox(
                            width: 28,
                            child: Text(
                              'P',
                              textAlign: TextAlign.center,
                              style: _headerStyle,
                            ),
                          ),
                          SizedBox(
                            width: 28,
                            child: Text(
                              'W',
                              textAlign: TextAlign.center,
                              style: _headerStyle,
                            ),
                          ),
                          SizedBox(
                            width: 28,
                            child: Text(
                              'D',
                              textAlign: TextAlign.center,
                              style: _headerStyle,
                            ),
                          ),
                          SizedBox(
                            width: 28,
                            child: Text(
                              'L',
                              textAlign: TextAlign.center,
                              style: _headerStyle,
                            ),
                          ),
                          SizedBox(
                            width: 34,
                            child: Text(
                              'PTS',
                              textAlign: TextAlign.center,
                              style: _headerStyle,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // TEAMS
                    _StandingRow(
                      position: 1,
                      team: 'Mashava',
                      played: 6,
                      won: 5,
                      drawn: 0,
                      lost: 1,
                      points: 15,
                      first: true,
                    ),

                    _StandingRow(
                      position: 2,
                      team: 'GZU Main',
                      played: 6,
                      won: 4,
                      drawn: 0,
                      lost: 2,
                      points: 12,
                    ),

                    _StandingRow(
                      position: 3,
                      team: 'City Campus',
                      played: 6,
                      won: 3,
                      drawn: 1,
                      lost: 2,
                      points: 10,
                    ),

                    _StandingRow(
                      position: 4,
                      team: 'Mucheke',
                      played: 6,
                      won: 1,
                      drawn: 1,
                      lost: 4,
                      points: 4,
                      last: true,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 22),

              // LEGEND
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF3ED),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Row(
                  children: [
                    Icon(
                      Icons.info_outline_rounded,
                      size: 18,
                      color: Color(0xFF0F3D24),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'P = Played   W = Wins   D = Draws   L = Losses   PTS = Points',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF365342),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 18),

              Center(
                child: Text(
                  'Standings update automatically as results are published',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey.shade500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

const TextStyle _headerStyle = TextStyle(
  fontSize: 9,
  fontWeight: FontWeight.w800,
  letterSpacing: 0.8,
  color: Color(0xFF6E766F),
);

class _StandingRow extends StatelessWidget {
  final int position;
  final String team;
  final int played;
  final int won;
  final int drawn;
  final int lost;
  final int points;
  final bool first;
  final bool last;

  const _StandingRow({
    required this.position,
    required this.team,
    required this.played,
    required this.won,
    required this.drawn,
    required this.lost,
    required this.points,
    this.first = false,
    this.last = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      decoration: BoxDecoration(
        border: last
            ? null
            : const Border(
                bottom: BorderSide(
                  color: Color(0xFFE9EBE6),
                ),
              ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 30,
            child: Text(
              '$position',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: first
                    ? const Color(0xFF0F3D24)
                    : const Color(0xFF6E766F),
              ),
            ),
          ),

          Expanded(
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: first
                        ? const Color(0xFFEAF3ED)
                        : const Color(0xFFF2F3F0),
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    _initials(team),
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                      color: first
                          ? const Color(0xFF0F3D24)
                          : const Color(0xFF6E766F),
                    ),
                  ),
                ),
                const SizedBox(width: 9),
                Flexible(
                  child: Text(
                    team,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: first
                          ? FontWeight.w800
                          : FontWeight.w600,
                      color: const Color(0xFF141B16),
                    ),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(
            width: 28,
            child: Text(
              '$played',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF6E766F),
              ),
            ),
          ),

          SizedBox(
            width: 28,
            child: Text(
              '$won',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF6E766F),
              ),
            ),
          ),

          SizedBox(
            width: 28,
            child: Text(
              '$drawn',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF6E766F),
              ),
            ),
          ),

          SizedBox(
            width: 28,
            child: Text(
              '$lost',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF6E766F),
              ),
            ),
          ),

          SizedBox(
            width: 34,
            child: Text(
              '$points',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w900,
                color: Color(0xFF0F3D24),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _initials(String name) {
    final words = name.split(' ');

    if (words.length == 1) {
      return name.substring(
        0,
        name.length >= 2 ? 2 : 1,
      ).toUpperCase();
    }

    return '${words.first[0]}${words.last[0]}'.toUpperCase();
  }
}