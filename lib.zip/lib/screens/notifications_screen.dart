
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() =>
      _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  static const String _storageKey = 'gzu_notification_read_status';

  bool _isLoading = true;
  SharedPreferences? _prefs;

  final List<Map<String, dynamic>> notifications = [
    {
      'id': 'fixture_mashava_city',
      'type': 'Fixture',
      'title': 'New Fixture Added',
      'message':
          'Mashava will face City Campus in the upcoming rugby fixture.',
      'time': '2 hours ago',
      'icon': Icons.calendar_month_rounded,
      'unread': true,
    },
    {
      'id': 'result_gzu_mucheke',
      'type': 'Result',
      'title': 'Match Result Available',
      'message':
          'GZU Main defeated Mucheke 2–1 in the latest football fixture.',
      'time': 'Yesterday',
      'icon': Icons.emoji_events_rounded,
      'unread': true,
    },
    {
      'id': 'reminder_mashava_city',
      'type': 'Reminder',
      'title': 'Match Reminder',
      'message':
          'Rugby: Mashava vs City Campus starts Saturday at 15:00.',
      'time': 'Yesterday',
      'icon': Icons.notifications_active_rounded,
      'unread': false,
    },
    {
      'id': 'sports_hub_update',
      'type': 'Update',
      'title': 'Sports Hub Updated',
      'message':
          'Fixtures and results have been updated with the latest information.',
      'time': '3 days ago',
      'icon': Icons.sync_rounded,
      'unread': false,
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadReadStatus();
  }

  Future<void> _loadReadStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedStatus = prefs.getStringList(_storageKey);

      if (!mounted) return;

      _prefs = prefs;

      if (savedStatus != null) {
        final readIds = savedStatus.toSet();

        for (final notification in notifications) {
          notification['unread'] =
              !readIds.contains(notification['id']);
        }
      }
    } catch (_) {
      // If storage is unavailable, the screen still works in memory.
    }

    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _saveReadStatus() async {
    try {
      final prefs =
          _prefs ?? await SharedPreferences.getInstance();

      _prefs = prefs;

      final readIds = notifications
          .where((notification) => notification['unread'] == false)
          .map((notification) => notification['id'] as String)
          .toList();

      await prefs.setStringList(_storageKey, readIds);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Read status could not be saved on this device.',
            ),
          ),
        );
      }
    }
  }

  Future<void> _markAsRead(Map<String, dynamic> notification) async {
    if (notification['unread'] != true) return;

    setState(() {
      notification['unread'] = false;
    });

    await _saveReadStatus();
  }

  Future<void> _markAllAsRead() async {
    setState(() {
      for (final notification in notifications) {
        notification['unread'] = false;
      }
    });

    await _saveReadStatus();
  }

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF0B2E1C);
    const primaryLight = Color(0xFF1E9553);
    const accent = Color(0xFFC6FF4D);
    const bg = Color(0xFFF4F7F3);
    const ink = Color(0xFF10160F);
    const inkSoft = Color(0xFF6C766A);
    const line = Color(0xFFE6EAE1);

    final unreadCount = notifications
        .where((notification) => notification['unread'] == true)
        .length;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleSpacing: 20,
        title: const Text(
          'Notifications',
          style: TextStyle(
            color: ink,
            fontSize: 24,
            fontWeight: FontWeight.w800,
            letterSpacing: -0.5,
          ),
        ),
        actions: [
          if (!_isLoading && unreadCount > 0)
            Padding(
              padding: const EdgeInsets.only(right: 18),
              child: TextButton(
                onPressed: _markAllAsRead,
                child: const Text(
                  'Mark all read',
                  style: TextStyle(
                    color: primaryLight,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(
                color: primaryLight,
              ),
            )
          : notifications.isEmpty
              ? const _EmptyNotifications()
              : RefreshIndicator(
                  color: primaryLight,
                  onRefresh: _loadReadStatus,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
                    children: [
                      _NotificationSummary(
                        unreadCount: unreadCount,
                        primary: primary,
                        accent: accent,
                      ),
                      const SizedBox(height: 22),
                      const Text(
                        'Recent activity',
                        style: TextStyle(
                          color: ink,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...notifications.map(
                        (notification) => _NotificationCard(
                          title: notification['title'] as String,
                          message: notification['message'] as String,
                          time: notification['time'] as String,
                          type: notification['type'] as String,
                          icon: notification['icon'] as IconData,
                          unread: notification['unread'] as bool,
                          primary: primary,
                          primaryLight: primaryLight,
                          accent: accent,
                          line: line,
                          ink: ink,
                          inkSoft: inkSoft,
                          onTap: () => _markAsRead(notification),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _NotificationSummary extends StatelessWidget {
  final int unreadCount;
  final Color primary;
  final Color accent;

  const _NotificationSummary({
    required this.unreadCount,
    required this.primary,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: primary,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: primary.withValues(alpha: 0.14),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: accent,
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(
              Icons.notifications_rounded,
              color: Color(0xFF0B2E1C),
              size: 25,
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  unreadCount == 0
                      ? 'You are all caught up'
                      : '$unreadCount unread notification${unreadCount == 1 ? '' : 's'}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Stay updated with GZU Sports Hub.',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NotificationCard extends StatelessWidget {
  final String title;
  final String message;
  final String time;
  final String type;
  final IconData icon;
  final bool unread;
  final Color primary;
  final Color primaryLight;
  final Color accent;
  final Color line;
  final Color ink;
  final Color inkSoft;
  final VoidCallback onTap;

  const _NotificationCard({
    required this.title,
    required this.message,
    required this.time,
    required this.type,
    required this.icon,
    required this.unread,
    required this.primary,
    required this.primaryLight,
    required this.accent,
    required this.line,
    required this.ink,
    required this.inkSoft,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: unread
              ? Colors.white
              : Colors.white.withValues(alpha: 0.72),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: unread
                ? primaryLight.withValues(alpha: 0.20)
                : line,
          ),
          boxShadow: unread
              ? [
                  BoxShadow(
                    color: primary.withValues(alpha: 0.05),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: unread
                    ? accent.withValues(alpha: 0.32)
                    : const Color(0xFFECEFEC),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(
                icon,
                color: unread ? primary : inkSoft,
                size: 21,
              ),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          title,
                          style: TextStyle(
                            color: ink,
                            fontSize: 14.5,
                            fontWeight: unread
                                ? FontWeight.w800
                                : FontWeight.w700,
                          ),
                        ),
                      ),
                      if (unread)
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Color(0xFF1E9553),
                            shape: BoxShape.circle,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    message,
                    style: TextStyle(
                      color: inkSoft,
                      fontSize: 12.5,
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Text(
                        type.toUpperCase(),
                        style: TextStyle(
                          color: primaryLight,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 3,
                        height: 3,
                        decoration: BoxDecoration(
                          color: inkSoft.withValues(alpha: 0.5),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        time,
                        style: TextStyle(
                          color: inkSoft.withValues(alpha: 0.85),
                          fontSize: 10.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyNotifications extends StatelessWidget {
  const _EmptyNotifications();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(35),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F0E9),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Icon(
                Icons.notifications_none_rounded,
                color: Color(0xFF1E9553),
                size: 34,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'No notifications yet',
              style: TextStyle(
                color: Color(0xFF10160F),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 7),
            const Text(
              'New fixtures, results and sports updates will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF6C766A),
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}