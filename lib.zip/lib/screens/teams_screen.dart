import 'package:flutter/material.dart';

class TeamsScreen extends StatefulWidget {
  const TeamsScreen({super.key});

  @override
  State<TeamsScreen> createState() => _TeamsScreenState();
}

class _TeamsScreenState extends State<TeamsScreen> {
  String selectedSport = 'All';

  final List<Map<String, dynamic>> teams = [
    {
      'name': 'Mashava',
      'sport': 'Rugby',
      'players': 24,
      'description': 'GZU rugby team competing in university fixtures.',
      'icon': Icons.sports_rugby_rounded,
    },
    {
      'name': 'GZU Main',
      'sport': 'Football',
      'players': 22,
      'description': 'University football team representing GZU.',
      'icon': Icons.sports_soccer_rounded,
    },
    {
      'name': 'GZU Titans',
      'sport': 'Basketball',
      'players': 15,
      'description': 'Competitive basketball team representing GZU.',
      'icon': Icons.sports_basketball_rounded,
    },
    {
      'name': 'GZU Queens',
      'sport': 'Netball',
      'players': 14,
      'description': 'GZU women’s netball team.',
      'icon': Icons.sports_handball_rounded,
    },
    {
      'name': 'City Campus',
      'sport': 'Rugby',
      'players': 23,
      'description': 'University rugby side competing in GZU fixtures.',
      'icon': Icons.sports_rugby_rounded,
    },
    {
      'name': 'Mucheke',
      'sport': 'Football',
      'players': 21,
      'description': 'Football team competing in university fixtures.',
      'icon': Icons.sports_soccer_rounded,
    },
  ];

  final List<String> sports = [
    'All',
    'Rugby',
    'Football',
    'Basketball',
    'Netball',
  ];

  @override
  Widget build(BuildContext context) {
    final filteredTeams = selectedSport == 'All'
        ? teams
        : teams
            .where((team) => team['sport'] == selectedSport)
            .toList();

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7F3),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF4F7F3),
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 20,
            color: Color(0xFF10160F),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Teams',
          style: TextStyle(
            color: Color(0xFF10160F),
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildIntro(),
            _buildSportFilters(),
            const SizedBox(height: 8),
            Expanded(
              child: filteredTeams.isEmpty
                  ? _buildEmptyState()
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 30),
                      itemCount: filteredTeams.length,
                      separatorBuilder: (_, _) =>
                          const SizedBox(height: 14),
                      itemBuilder: (context, index) {
                        return _buildTeamCard(filteredTeams[index]);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIntro() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 14),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          'Explore teams representing Great Zimbabwe University.',
          style: TextStyle(
            color: const Color(0xFF6C766A),
            fontSize: 14,
            height: 1.4,
          ),
        ),
      ),
    );
  }

  Widget _buildSportFilters() {
    return SizedBox(
      height: 42,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: sports.length,
        separatorBuilder: (_, _) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final sport = sports[index];
          final selected = sport == selectedSport;

          return GestureDetector(
            onTap: () {
              setState(() {
                selectedSport = sport;
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 17),
              decoration: BoxDecoration(
                color: selected
                    ? const Color(0xFF0B2E1C)
                    : Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: selected
                      ? const Color(0xFF0B2E1C)
                      : const Color(0xFFE6EAE1),
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                sport,
                style: TextStyle(
                  color: selected
                      ? const Color(0xFFC6FF4D)
                      : const Color(0xFF10160F),
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTeamCard(Map<String, dynamic> team) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () {
          _showTeamDetails(team);
        },
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: const Color(0xFFE4FFB0),
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Icon(
                  team['icon'],
                  color: const Color(0xFF0B2E1C),
                  size: 28,
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      team['name'],
                      style: const TextStyle(
                        color: Color(0xFF10160F),
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      team['sport'],
                      style: const TextStyle(
                        color: Color(0xFF1E9553),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: [
                        const Icon(
                          Icons.people_alt_outlined,
                          size: 15,
                          color: Color(0xFF6C766A),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          '${team['players']} players',
                          style: const TextStyle(
                            color: Color(0xFF6C766A),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios_rounded,
                size: 16,
                color: Color(0xFF9AA398),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(
              Icons.groups_rounded,
              size: 55,
              color: Color(0xFF9AA398),
            ),
            SizedBox(height: 14),
            Text(
              'No teams available',
              style: TextStyle(
                color: Color(0xFF10160F),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(height: 6),
            Text(
              'There are no teams available for this sport yet.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF6C766A),
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showTeamDetails(Map<String, dynamic> team) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 55,
                    height: 55,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE4FFB0),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      team['icon'],
                      color: const Color(0xFF0B2E1C),
                      size: 27,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          team['name'],
                          style: const TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF10160F),
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          team['sport'],
                          style: const TextStyle(
                            color: Color(0xFF1E9553),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                team['description'],
                style: const TextStyle(
                  color: Color(0xFF6C766A),
                  fontSize: 14,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  const Icon(
                    Icons.people_alt_outlined,
                    color: Color(0xFF0B2E1C),
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '${team['players']} players',
                    style: const TextStyle(
                      color: Color(0xFF10160F),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}