import 'package:flutter/material.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key});

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  String selectedSport = 'All';

  final List<Map<String, dynamic>> results = [
    {
      'sport': 'Rugby',
      'home': 'Mashava',
      'away': 'GZU Main',
      'scoreHome': 24,
      'scoreAway': 17,
      'date': '05 SEP',
      'venue': 'Primary Field',
      'status': 'WON',
    },
    {
      'sport': 'Football',
      'home': 'Mucheke',
      'away': 'GZU Main',
      'scoreHome': 1,
      'scoreAway': 2,
      'date': '03 SEP',
      'venue': 'GZU Sports Ground',
      'status': 'WON',
    },
    {
      'sport': 'Basketball',
      'home': 'GZU Titans',
      'away': 'Mashava',
      'scoreHome': 68,
      'scoreAway': 68,
      'date': '30 AUG',
      'venue': 'Indoor Arena',
      'status': 'DRAW',
    },
    {
      'sport': 'Netball',
      'home': 'GZU Queens',
      'away': 'City Campus',
      'scoreHome': 42,
      'scoreAway': 35,
      'date': '28 AUG',
      'venue': 'Main Courts',
      'status': 'WON',
    },
  ];

  final List<String> sports = [
    'All',
    'Rugby',
    'Football',
    'Basketball',
    'Netball',
  ];

  @override
  Widget build(BuildContext context) {
    final filteredResults = selectedSport == 'All'
        ? results
        : results
            .where((result) => result['sport'] == selectedSport)
            .toList();

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7F3),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF4F7F3),
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 20,
            color: Color(0xFF10160F),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Results',
          style: TextStyle(
            color: Color(0xFF10160F),
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 4, 20, 14),
              child: Text(
                'Recent results from GZU university sports.',
                style: TextStyle(
                  color: Color(0xFF6C766A),
                  fontSize: 14,
                  height: 1.4,
                ),
              ),
            ),

            // SPORT FILTERS
            SizedBox(
              height: 44,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                scrollDirection: Axis.horizontal,
                itemCount: sports.length,
                separatorBuilder: (_, _) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final sport = sports[index];
                  final isSelected = sport == selectedSport;

                  return Material(
                    color: isSelected
                        ? const Color(0xFF0B2E1C)
                        : Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () {
                        setState(() {
                          selectedSport = sport;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 17),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF0B2E1C)
                                : const Color(0xFFE6EAE1),
                          ),
                        ),
                        child: Text(
                          sport,
                          style: TextStyle(
                            color: isSelected
                                ? const Color(0xFFC6FF4D)
                                : const Color(0xFF10160F),
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 8),

            Expanded(
              child: filteredResults.isEmpty
                  ? _buildEmptyState()
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 30),
                      itemCount: filteredResults.length,
                      separatorBuilder: (_, _) =>
                          const SizedBox(height: 14),
                      itemBuilder: (context, index) {
                        return _buildResultCard(filteredResults[index]);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard(Map<String, dynamic> result) {
    final status = result['status'].toString();
    final isDraw = status == 'DRAW';

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => _showResultDetails(result),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: Color(0xFF1E9553),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    result['sport'].toString().toUpperCase(),
                    style: const TextStyle(
                      color: Color(0xFF7B857C),
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.3,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: isDraw
                          ? const Color(0xFFFFF5D9)
                          : const Color(0xFFE4F8EA),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      status,
                      style: TextStyle(
                        color: isDraw
                            ? const Color(0xFFAD7A12)
                            : const Color(0xFF1E9553),
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),

              Row(
                children: [
                  Expanded(
                    child: _ScoreTeam(
                      name: result['home'],
                      score: result['scoreHome'],
                      emphasized: result['scoreHome'] >= result['scoreAway'],
                    ),
                  ),
                  const SizedBox(width: 16),
                  const Text(
                    '-',
                    style: TextStyle(
                      color: Color(0xFF9AA398),
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _ScoreTeam(
                      name: result['away'],
                      score: result['scoreAway'],
                      emphasized: result['scoreAway'] > result['scoreHome'],
                      rightAligned: true,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),
              Container(
                height: 1,
                color: const Color(0xFFE6EAE1),
              ),
              const SizedBox(height: 13),

              Row(
                children: [
                  const Icon(
                    Icons.calendar_today_outlined,
                    size: 15,
                    color: Color(0xFF6C766A),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    result['date'],
                    style: const TextStyle(
                      color: Color(0xFF6C766A),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  const Icon(
                    Icons.location_on_outlined,
                    size: 15,
                    color: Color(0xFF6C766A),
                  ),
                  const SizedBox(width: 5),
                  Flexible(
                    child: Text(
                      result['venue'],
                      textAlign: TextAlign.right,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF6C766A),
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(
              Icons.bar_chart_rounded,
              size: 55,
              color: Color(0xFF9AA398),
            ),
            SizedBox(height: 14),
            Text(
              'No results available',
              style: TextStyle(
                color: Color(0xFF10160F),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(height: 6),
            Text(
              'There are no results available for this sport yet.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF6C766A),
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showResultDetails(Map<String, dynamic> result) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      builder: (context) {
        final isDraw = result['status'] == 'DRAW';

        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                result['sport'].toString().toUpperCase(),
                style: const TextStyle(
                  color: Color(0xFF1E9553),
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '${result['home']} ${result['scoreHome']} - ${result['scoreAway']} ${result['away']}',
                style: const TextStyle(
                  color: Color(0xFF10160F),
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 18),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: isDraw
                      ? const Color(0xFFFFF5D9)
                      : const Color(0xFFE4F8EA),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  result['status'],
                  style: TextStyle(
                    color: isDraw
                        ? const Color(0xFFAD7A12)
                        : const Color(0xFF1E9553),
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _DetailRow(
                icon: Icons.calendar_today_outlined,
                text: result['date'],
              ),
              const SizedBox(height: 12),
              _DetailRow(
                icon: Icons.location_on_outlined,
                text: result['venue'],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ScoreTeam extends StatelessWidget {
  final String name;
  final int score;
  final bool emphasized;
  final bool rightAligned;

  const _ScoreTeam({
    required this.name,
    required this.score,
    required this.emphasized,
    this.rightAligned = false,
  });

  @override
  Widget build(BuildContext context) {
    final cleanName = name.trim();
    final parts = cleanName
        .split(RegExp(r'\\s+'))
        .where((part) => part.isNotEmpty)
        .toList();

    final initials = parts.length >= 2
        ? parts.take(2).map((part) => part[0]).join().toUpperCase()
        : cleanName.length <= 3
            ? cleanName.toUpperCase()
            : cleanName.substring(0, 3).toUpperCase();

    return Column(
      crossAxisAlignment: rightAligned
          ? CrossAxisAlignment.end
          : CrossAxisAlignment.start,
      children: [
        Container(
          width: 48,
          height: 48,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: emphasized
                ? const Color(0xFFE4FFB0)
                : const Color(0xFFF0F3EE),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Text(
            initials,
            style: const TextStyle(
              color: Color(0xFF0B2E1C),
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          name,
          textAlign: rightAligned ? TextAlign.right : TextAlign.left,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: emphasized
                ? const Color(0xFF10160F)
                : const Color(0xFF6C766A),
            fontSize: 13,
            fontWeight: emphasized
                ? FontWeight.w800
                : FontWeight.w600,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '$score',
          style: TextStyle(
            color: emphasized
                ? const Color(0xFF10160F)
                : const Color(0xFF6C766A),
            fontSize: 24,
            fontWeight: emphasized
                ? FontWeight.w900
                : FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String text;

  const _DetailRow({
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: 19,
          color: const Color(0xFF0B2E1C),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(
              color: Color(0xFF10160F),
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}
