import 'package:flutter/material.dart';

class UpdatesScreen extends StatefulWidget {
  const UpdatesScreen({super.key});

  @override
  State<UpdatesScreen> createState() => _UpdatesScreenState();
}

class _UpdatesScreenState extends State<UpdatesScreen> {
  final List<Map<String, dynamic>> updates = [
    {
      'type': 'Sports Department',
      'title': 'Welcome to GZU Sports Hub',
      'description':
          'Stay updated with the latest fixtures, results, teams and sports announcements from Great Zimbabwe University.',
      'date': 'Today',
      'icon': Icons.campaign_rounded,
    },
    {
      'type': 'Rugby',
      'title': 'Rugby Fixture Confirmed',
      'description':
          'Mashava will face City Campus in the upcoming rugby fixture at Primary Field.',
      'date': 'Today',
      'icon': Icons.sports_rugby_rounded,
    },
    {
      'type': 'Football',
      'title': 'Football Results Updated',
      'description':
          'The latest football results have been added to the GZU Sports Hub.',
      'date': 'Yesterday',
      'icon': Icons.sports_soccer_rounded,
    },
    {
      'type': 'General',
      'title': 'Sports Hub Information',
      'description':
          'Students can now view fixtures, results, standings and participating teams from one place.',
      'date': '3 days ago',
      'icon': Icons.info_outline_rounded,
    },
  ];

  Future<void> _refreshUpdates() async {
    await Future.delayed(const Duration(milliseconds: 700));

    if (!mounted) return;

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F7F3),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF4F7F3),
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 20,
            color: Color(0xFF10160F),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Updates',
          style: TextStyle(
            color: Color(0xFF10160F),
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: RefreshIndicator(
        color: const Color(0xFF0B2E1C),
        onRefresh: _refreshUpdates,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
          children: [
            _buildHeader(),
            const SizedBox(height: 20),

            ...updates.map(
              (update) => Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: _buildUpdateCard(update),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF0B2E1C),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFC6FF4D),
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(
              Icons.notifications_active_outlined,
              color: Color(0xFF0B2E1C),
              size: 25,
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Latest Updates',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Important sports news and announcements.',
                  style: TextStyle(
                    color: Color(0xFFD7E1D8),
                    fontSize: 13,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUpdateCard(Map<String, dynamic> update) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () {
          _showUpdateDetails(update);
        },
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: const Color(0xFFE4FFB0),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  update['icon'],
                  color: const Color(0xFF0B2E1C),
                  size: 25,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            update['type'],
                            style: const TextStyle(
                              color: Color(0xFF1E9553),
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        Text(
                          update['date'],
                          style: const TextStyle(
                            color: Color(0xFF9AA398),
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      update['title'],
                      style: const TextStyle(
                        color: Color(0xFF10160F),
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      update['description'],
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF6C766A),
                        fontSize: 13,
                        height: 1.45,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Row(
                      children: [
                        Text(
                          'Read more',
                          style: TextStyle(
                            color: Color(0xFF0B2E1C),
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(width: 4),
                        Icon(
                          Icons.arrow_forward_rounded,
                          size: 15,
                          color: Color(0xFF0B2E1C),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showUpdateDetails(Map<String, dynamic> update) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 55,
                    height: 55,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE4FFB0),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      update['icon'],
                      color: const Color(0xFF0B2E1C),
                      size: 27,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          update['type'],
                          style: const TextStyle(
                            color: Color(0xFF1E9553),
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          update['title'],
                          style: const TextStyle(
                            color: Color(0xFF10160F),
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                update['description'],
                style: const TextStyle(
                  color: Color(0xFF6C766A),
                  fontSize: 14,
                  height: 1.55,
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  const Icon(
                    Icons.schedule_rounded,
                    size: 18,
                    color: Color(0xFF0B2E1C),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    update['date'],
                    style: const TextStyle(
                      color: Color(0xFF10160F),
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}