import 'package:cloud_firestore/cloud_firestore.dart';

/// Sports offered in the app. The admin picks from this list and the student
/// filter chips use the same list, so the two always match.
const List<String> kSports = ['Rugby', 'Football', 'Basketball', 'Netball'];

const List<String> kNotificationTypes = [
  'Fixture',
  'Result',
  'Reminder',
  'Update',
];

/// One place that knows the Firestore collection names.
class Db {
  Db._();

  static final FirebaseFirestore _fs = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> get fixtures =>
      _fs.collection('fixtures');

  static CollectionReference<Map<String, dynamic>> get notifications =>
      _fs.collection('notifications');

  static Query<Map<String, dynamic>> get fixturesByDate =>
      fixtures.orderBy('kickoff');

  static Query<Map<String, dynamic>> get latestNotifications =>
      notifications.orderBy('createdAt', descending: true).limit(50);
}

const List<String> _weekdays = [
  'MON',
  'TUE',
  'WED',
  'THU',
  'FRI',
  'SAT',
  'SUN',
];

const List<String> _monthsShort = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

const List<String> _monthsLong = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

String _two(int n) => n.toString().padLeft(2, '0');

class Fixture {
  final String id;
  final String sport;
  final String home;
  final String away;
  final String venue;
  final DateTime kickoff;

  const Fixture({
    required this.id,
    required this.sport,
    required this.home,
    required this.away,
    required this.venue,
    required this.kickoff,
  });

  factory Fixture.fromDoc(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    return Fixture(
      id: doc.id,
      sport: d['sport']?.toString() ?? '',
      home: d['home']?.toString() ?? '',
      away: d['away']?.toString() ?? '',
      venue: d['venue']?.toString() ?? '',
      kickoff: (d['kickoff'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  /// SAT
  String get weekdayShort => _weekdays[kickoff.weekday - 1];

  /// 12 Sep 2026
  String get dateLabel =>
      '${kickoff.day} ${_monthsShort[kickoff.month - 1]} ${kickoff.year}';

  /// Sat, 12 Sep (short, for cards)
  String get cardDateLabel =>
      '$weekdayShort, ${kickoff.day} ${_monthsShort[kickoff.month - 1]}';

  /// SAT, 12 September 2026 (for the details sheet)
  String get longDateLabel =>
      '$weekdayShort, ${kickoff.day} ${_monthsLong[kickoff.month - 1]} ${kickoff.year}';

  /// 15:00
  String get timeLabel => '${_two(kickoff.hour)}:${_two(kickoff.minute)}';
}

class AppNotification {
  final String id;
  final String type;
  final String title;
  final String message;
  final DateTime createdAt;

  const AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.message,
    required this.createdAt,
  });

  factory AppNotification.fromDoc(
    QueryDocumentSnapshot<Map<String, dynamic>> doc,
  ) {
    final d = doc.data();
    return AppNotification(
      id: doc.id,
      type: d['type']?.toString() ?? 'Update',
      title: d['title']?.toString() ?? '',
      message: d['message']?.toString() ?? '',
      // createdAt is null for a split second on the device that just wrote it
      // (the server hasn't stamped it yet), so fall back to "now".
      createdAt: (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  String get timeAgo => formatTimeAgo(createdAt);
}

String formatTimeAgo(DateTime time) {
  final diff = DateTime.now().difference(time);

  if (diff.inMinutes < 1) return 'Just now';
  if (diff.inMinutes < 60) return '${diff.inMinutes} min ago';
  if (diff.inHours < 24) {
    final h = diff.inHours;
    return '$h hour${h == 1 ? '' : 's'} ago';
  }
  if (diff.inHours < 48) return 'Yesterday';
  if (diff.inDays < 7) return '${diff.inDays} days ago';
  return '${time.day} ${_monthsShort[time.month - 1]} ${time.year}';
}
