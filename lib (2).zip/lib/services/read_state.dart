import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'db.dart';

/// Remembers which notifications this device has already opened.
///
/// It is a singleton that lives for the whole app session, so the read state
/// survives leaving and re-opening the Notifications screen even if saving to
/// disk ever fails. It is also saved to SharedPreferences so it survives
/// app restarts.
class ReadState {
  ReadState._();

  static final ReadState instance = ReadState._();

  static const String _key = 'gzu_notification_read_ids';

  /// `null` means "still loading from disk".
  final ValueNotifier<Set<String>?> readIds = ValueNotifier<Set<String>?>(null);

  bool _loading = false;

  Future<void> ensureLoaded() async {
    if (readIds.value != null || _loading) return;
    _loading = true;

    try {
      final prefs = await SharedPreferences.getInstance();
      readIds.value = (prefs.getStringList(_key) ?? <String>[]).toSet();
    } catch (e) {
      // Disk unavailable: carry on with in-memory state for this session.
      debugPrint('ReadState load failed: $e');
      readIds.value = <String>{};
    } finally {
      _loading = false;
    }
  }

  Future<void> markRead(Iterable<String> ids) async {
    await ensureLoaded();

    final current = readIds.value ?? <String>{};
    final next = {...current, ...ids};
    if (next.length == current.length) return;

    // Update memory first so the UI changes instantly.
    readIds.value = next;

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_key, next.toList());
    } catch (e) {
      debugPrint('ReadState save failed: $e');
    }
  }
}

/// Small lime dot for the home-screen bell. Only shows when there is at least
/// one notification this device has not opened yet.
class UnreadDot extends StatefulWidget {
  const UnreadDot({super.key});

  @override
  State<UnreadDot> createState() => _UnreadDotState();
}

class _UnreadDotState extends State<UnreadDot> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream =
      Db.latestNotifications.snapshots();

  @override
  void initState() {
    super.initState();
    ReadState.instance.ensureLoaded();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _stream,
      builder: (context, snapshot) {
        final docs = snapshot.data?.docs ??
            <QueryDocumentSnapshot<Map<String, dynamic>>>[];

        return ValueListenableBuilder<Set<String>?>(
          valueListenable: ReadState.instance.readIds,
          builder: (context, readIds, _) {
            if (readIds == null) return const SizedBox.shrink();

            final hasUnread = docs.any((d) => !readIds.contains(d.id));
            if (!hasUnread) return const SizedBox.shrink();

            return Container(
              width: 7,
              height: 7,
              decoration: const BoxDecoration(
                color: Color(0xFFB8FF3C),
                shape: BoxShape.circle,
              ),
            );
          },
        );
      },
    );
  }
}
