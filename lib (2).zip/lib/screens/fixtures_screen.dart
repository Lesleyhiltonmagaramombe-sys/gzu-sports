import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../services/db.dart';

class FixturesScreen extends StatefulWidget {
  const FixturesScreen({super.key});

  @override
  State<FixturesScreen> createState() => _FixturesScreenState();
}

class _FixturesScreenState extends State<FixturesScreen> {
  String selectedSport = 'All';

  // Live feed from Firestore: whatever the admin adds, edits or deletes shows
  // up here instantly. Created once so it isn't re-subscribed on setState.
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream =
      Db.fixturesByDate.snapshots();

  final List<String> sports = ['All', ...kSports];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F7F3),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF4F7F3),
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 20,
            color: Color(0xFF10160F),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Fixtures',
          style: TextStyle(
            color: Color(0xFF10160F),
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 4, 20, 14),
              child: Text(
                'Upcoming games and scheduled university fixtures.',
                style: TextStyle(
                  color: Color(0xFF6C766A),
                  fontSize: 14,
                  height: 1.4,
                ),
              ),
            ),

            // SPORT FILTERS
            SizedBox(
              height: 44,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                scrollDirection: Axis.horizontal,
                itemCount: sports.length,
                separatorBuilder: (_, _) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final sport = sports[index];
                  final isSelected = sport == selectedSport;

                  return Material(
                    color: isSelected
                        ? const Color(0xFF0B2E1C)
                        : Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () {
                        setState(() {
                          selectedSport = sport;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 17),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF0B2E1C)
                                : const Color(0xFFE6EAE1),
                          ),
                        ),
                        child: Text(
                          sport,
                          style: TextStyle(
                            color: isSelected
                                ? const Color(0xFFC6FF4D)
                                : const Color(0xFF10160F),
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 8),

            Expanded(
              child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: _stream,
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return _buildMessageState(
                      icon: Icons.cloud_off_rounded,
                      title: 'Could not load fixtures',
                      message: 'Check your connection and try again.',
                    );
                  }

                  if (!snapshot.hasData) {
                    return const Center(
                      child: CircularProgressIndicator(
                        color: Color(0xFF1E9553),
                      ),
                    );
                  }

                  // Hide games that finished more than 3 hours ago.
                  final cutoff =
                      DateTime.now().subtract(const Duration(hours: 3));

                  final filteredFixtures = snapshot.data!.docs
                      .map(Fixture.fromDoc)
                      .where((f) => f.kickoff.isAfter(cutoff))
                      .where(
                        (f) =>
                            selectedSport == 'All' || f.sport == selectedSport,
                      )
                      .toList();

                  if (filteredFixtures.isEmpty) {
                    return _buildMessageState(
                      icon: Icons.event_busy_rounded,
                      title: 'No fixtures available',
                      message:
                          'There are no upcoming fixtures for this sport yet.',
                    );
                  }

                  return ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 30),
                    itemCount: filteredFixtures.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 14),
                    itemBuilder: (context, index) {
                      return _buildFixtureCard(filteredFixtures[index]);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFixtureCard(Fixture fixture) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => _showFixtureDetails(fixture),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE4FFB0),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Text(
                      fixture.sport.toUpperCase(),
                      style: const TextStyle(
                        color: Color(0xFF0B2E1C),
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  const Spacer(),
                  const Icon(
                    Icons.schedule_rounded,
                    size: 15,
                    color: Color(0xFF9AA398),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    fixture.timeLabel,
                    style: const TextStyle(
                      color: Color(0xFF6C766A),
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _TeamColumn(
                      name: fixture.home,
                      alignment: CrossAxisAlignment.start,
                    ),
                  ),
                  Container(
                    width: 38,
                    height: 38,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF0F3EE),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFFE6EAE1),
                      ),
                    ),
                    child: const Text(
                      'VS',
                      style: TextStyle(
                        color: Color(0xFF0B2E1C),
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  Expanded(
                    child: _TeamColumn(
                      name: fixture.away,
                      alignment: CrossAxisAlignment.end,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Container(
                height: 1,
                color: const Color(0xFFE6EAE1),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  const Icon(
                    Icons.calendar_today_outlined,
                    size: 16,
                    color: Color(0xFF6C766A),
                  ),
                  const SizedBox(width: 7),
                  Text(
                    fixture.cardDateLabel,
                    style: const TextStyle(
                      color: Color(0xFF6C766A),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  const Icon(
                    Icons.location_on_outlined,
                    size: 16,
                    color: Color(0xFF6C766A),
                  ),
                  const SizedBox(width: 5),
                  Flexible(
                    child: Text(
                      fixture.venue,
                      textAlign: TextAlign.right,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF6C766A),
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMessageState({
    required IconData icon,
    required String title,
    required String message,
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 55, color: const Color(0xFF9AA398)),
            const SizedBox(height: 14),
            Text(
              title,
              style: const TextStyle(
                color: Color(0xFF10160F),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF6C766A),
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showFixtureDetails(Fixture fixture) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(28),
        ),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                fixture.sport.toUpperCase(),
                style: const TextStyle(
                  color: Color(0xFF1E9553),
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '${fixture.home} vs ${fixture.away}',
                style: const TextStyle(
                  color: Color(0xFF10160F),
                  fontSize: 21,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 20),
              _DetailRow(
                icon: Icons.calendar_today_outlined,
                text: fixture.longDateLabel,
              ),
              const SizedBox(height: 12),
              _DetailRow(
                icon: Icons.schedule_rounded,
                text: fixture.timeLabel,
              ),
              const SizedBox(height: 12),
              _DetailRow(
                icon: Icons.location_on_outlined,
                text: fixture.venue,
              ),
            ],
          ),
        );
      },
    );
  }
}

class _TeamColumn extends StatelessWidget {
  final String name;
  final CrossAxisAlignment alignment;

  const _TeamColumn({
    required this.name,
    required this.alignment,
  });

  @override
  Widget build(BuildContext context) {
    final cleanName = name.trim();
    final parts = cleanName
        .split(RegExp(r'\s+'))
        .where((part) => part.isNotEmpty)
        .toList();

    final initials = parts.length >= 2
        ? parts.take(2).map((part) => part[0]).join().toUpperCase()
        : cleanName.length <= 3
            ? cleanName.toUpperCase()
            : cleanName.substring(0, 3).toUpperCase();

    return Column(
      crossAxisAlignment: alignment,
      children: [
        Container(
          width: 52,
          height: 52,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color(0xFFF0F3EE),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
            initials,
            style: const TextStyle(
              color: Color(0xFF0B2E1C),
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        const SizedBox(height: 9),
        Text(
          name,
          textAlign:
              alignment == CrossAxisAlignment.end
                  ? TextAlign.right
                  : TextAlign.left,
          style: const TextStyle(
            color: Color(0xFF10160F),
            fontSize: 14,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _DetailRow extends StatelessWidget {
  final IconData icon;
  final String text;

  const _DetailRow({
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: 19,
          color: const Color(0xFF0B2E1C),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: const TextStyle(
            color: Color(0xFF10160F),
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
