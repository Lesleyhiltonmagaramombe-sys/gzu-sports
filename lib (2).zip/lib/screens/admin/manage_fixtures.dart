import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../services/db.dart';

class ManageFixtures extends StatefulWidget {
  const ManageFixtures({super.key});

  @override
  State<ManageFixtures> createState() => _ManageFixturesState();
}

class _ManageFixturesState extends State<ManageFixtures> {
  // Live feed of every fixture, oldest kickoff first. Created once so the
  // stream isn't re-subscribed on every rebuild.
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream =
      Db.fixturesByDate.snapshots();

  void _toast(String message, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: error ? const Color(0xFFB3261E) : null,
      ),
    );
  }

  String _friendly(Object e) {
    if (e is FirebaseException && e.code == 'permission-denied') {
      return 'Permission denied. Check your Firestore rules and that this '
          'account has role "admin".';
    }
    return 'Something went wrong: $e';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Manage Fixtures',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: const Color(0xFFB8FF3C),
        onPressed: () => _showFixtureDialog(),
        child: const Icon(Icons.add_rounded),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return _errorState(_friendly(snapshot.error!));
          }

          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(color: Color(0xFF1B7A47)),
            );
          }

          final fixtures = snapshot.data!.docs.map(Fixture.fromDoc).toList();

          if (fixtures.isEmpty) return _emptyState();

          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
            itemCount: fixtures.length,
            itemBuilder: (context, index) => _fixtureCard(fixtures[index]),
          );
        },
      ),
    );
  }

  Widget _fixtureCard(Fixture fixture) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE1E6E2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Sport and menu
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F3EC),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  fixture.sport,
                  style: const TextStyle(
                    color: Color(0xFF0F3D24),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const Spacer(),
              PopupMenuButton<String>(
                icon: const Icon(
                  Icons.more_vert_rounded,
                  color: Color(0xFF68716B),
                ),
                onSelected: (value) {
                  if (value == 'edit') _showFixtureDialog(existing: fixture);
                  if (value == 'delete') _deleteFixture(fixture);
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(value: 'edit', child: Text('Edit fixture')),
                  PopupMenuItem(value: 'delete', child: Text('Delete fixture')),
                ],
              ),
            ],
          ),
          const SizedBox(height: 18),

          // Teams
          Row(
            children: [
              Expanded(child: _teamName(fixture.home, 'HOME')),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Text(
                  'VS',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF9AA39D),
                  ),
                ),
              ),
              Expanded(child: _teamName(fixture.away, 'AWAY', right: true)),
            ],
          ),
          const SizedBox(height: 18),
          const Divider(height: 1, color: Color(0xFFE8ECE9)),
          const SizedBox(height: 14),

          // Date + time
          Row(
            children: [
              const Icon(
                Icons.calendar_today_rounded,
                size: 16,
                color: Color(0xFF1B7A47),
              ),
              const SizedBox(width: 8),
              Text(
                fixture.dateLabel,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF39423C),
                ),
              ),
              const SizedBox(width: 18),
              const Icon(
                Icons.access_time_rounded,
                size: 16,
                color: Color(0xFF1B7A47),
              ),
              const SizedBox(width: 7),
              Text(
                fixture.timeLabel,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF39423C),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Venue
          Row(
            children: [
              const Icon(
                Icons.location_on_outlined,
                size: 17,
                color: Color(0xFF1B7A47),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  fixture.venue,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF68716B),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _teamName(String name, String label, {bool right = false}) {
    return Column(
      crossAxisAlignment:
          right ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 1,
            color: Color(0xFF9AA39D),
          ),
        ),
        const SizedBox(height: 5),
        Text(
          name,
          textAlign: right ? TextAlign.end : TextAlign.start,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: Color(0xFF141B16),
          ),
        ),
      ],
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3EC),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.calendar_month_rounded,
                size: 34,
                color: Color(0xFF0F3D24),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'No fixtures yet',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w800,
                color: Color(0xFF141B16),
              ),
            ),
            const SizedBox(height: 7),
            const Text(
              'Add a fixture using the + button. Students see it instantly.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Color(0xFF68716B)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _errorState(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              size: 46,
              color: Color(0xFFB3261E),
            ),
            const SizedBox(height: 14),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                height: 1.45,
                color: Color(0xFF68716B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------
  // ADD / EDIT
  // ------------------------------------------------------------------

  Future<void> _showFixtureDialog({Fixture? existing}) async {
    final isEditing = existing != null;

    final homeController = TextEditingController(text: existing?.home ?? '');
    final awayController = TextEditingController(text: existing?.away ?? '');
    final venueController = TextEditingController(text: existing?.venue ?? '');

    String sport = existing?.sport ?? kSports.first;
    // If an old fixture has a sport that isn't in the list, keep it selectable.
    final sportOptions = kSports.contains(sport) ? kSports : [...kSports, sport];

    DateTime date = existing?.kickoff ?? DateTime.now().add(const Duration(days: 1));
    TimeOfDay time = existing != null
        ? TimeOfDay.fromDateTime(existing.kickoff)
        : const TimeOfDay(hour: 15, minute: 0);

    bool saving = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(
                isEditing ? 'Edit Fixture' : 'Add Fixture',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      initialValue: sport,
                      decoration: _fieldDecoration('Sport', Icons.sports_rounded),
                      items: sportOptions
                          .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                          .toList(),
                      onChanged: (value) {
                        if (value == null) return;
                        setDialogState(() => sport = value);
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: homeController,
                      textCapitalization: TextCapitalization.words,
                      decoration:
                          _fieldDecoration('Home Team', Icons.home_rounded),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: awayController,
                      textCapitalization: TextCapitalization.words,
                      decoration:
                          _fieldDecoration('Away Team', Icons.groups_rounded),
                    ),
                    const SizedBox(height: 12),
                    _pickerTile(
                      icon: Icons.calendar_today_rounded,
                      label: 'Date',
                      value:
                          '${date.day}/${date.month.toString().padLeft(2, '0')}/${date.year}',
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: date,
                          firstDate: DateTime(2020),
                          lastDate: DateTime(2040),
                        );
                        if (picked != null) {
                          setDialogState(() => date = picked);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    _pickerTile(
                      icon: Icons.access_time_rounded,
                      label: 'Kick-off time',
                      value:
                          '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}',
                      onTap: () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: time,
                          builder: (context, child) => MediaQuery(
                            data: MediaQuery.of(context)
                                .copyWith(alwaysUse24HourFormat: true),
                            child: child!,
                          ),
                        );
                        if (picked != null) {
                          setDialogState(() => time = picked);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: venueController,
                      textCapitalization: TextCapitalization.words,
                      decoration: _fieldDecoration(
                        'Venue',
                        Icons.location_on_outlined,
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: saving ? null : () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0F3D24),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: saving
                      ? null
                      : () async {
                          final home = homeController.text.trim();
                          final away = awayController.text.trim();
                          final venue = venueController.text.trim();

                          if (home.isEmpty || away.isEmpty) {
                            _toast('Enter both team names.', error: true);
                            return;
                          }

                          setDialogState(() => saving = true);

                          final kickoff = DateTime(
                            date.year,
                            date.month,
                            date.day,
                            time.hour,
                            time.minute,
                          );

                          final data = <String, dynamic>{
                            'sport': sport,
                            'home': home,
                            'away': away,
                            'venue': venue.isEmpty ? 'Venue to be confirmed' : venue,
                            'kickoff': Timestamp.fromDate(kickoff),
                          };

                          try {
                            if (existing != null) {
                              await Db.fixtures.doc(existing.id).update(data);
                            } else {
                              await Db.fixtures.add({
                                ...data,
                                'createdAt': FieldValue.serverTimestamp(),
                              });
                            }

                            if (dialogContext.mounted) {
                              Navigator.pop(dialogContext);
                            }
                            _toast(
                              isEditing ? 'Fixture updated.' : 'Fixture added.',
                            );
                          } catch (e) {
                            if (dialogContext.mounted) {
                              setDialogState(() => saving = false);
                            }
                            _toast(_friendly(e), error: true);
                          }
                        },
                  child: saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text(isEditing ? 'Save Changes' : 'Add Fixture'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  InputDecoration _fieldDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    );
  }

  Widget _pickerTile({
    required IconData icon,
    required String label,
    required String value,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: InputDecorator(
        decoration: _fieldDecoration(label, icon),
        child: Text(
          value,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }

  // ------------------------------------------------------------------
  // DELETE
  // ------------------------------------------------------------------

  void _deleteFixture(Fixture fixture) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Delete Fixture?',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          content: Text(
            '${fixture.home} vs ${fixture.away} will be removed for everyone, '
            'including students.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(dialogContext);
                try {
                  await Db.fixtures.doc(fixture.id).delete();
                  _toast('Fixture deleted.');
                } catch (e) {
                  _toast(_friendly(e), error: true);
                }
              },
              child: const Text('Delete', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }
}
