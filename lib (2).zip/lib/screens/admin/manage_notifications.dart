import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../services/db.dart';

class ManageNotifications extends StatefulWidget {
  const ManageNotifications({super.key});

  @override
  State<ManageNotifications> createState() => _ManageNotificationsState();
}

class _ManageNotificationsState extends State<ManageNotifications> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream =
      Db.latestNotifications.snapshots();

  Color _typeColor(String type) {
    switch (type) {
      case 'Fixture':
        return const Color(0xFF0F3D24);
      case 'Result':
        return const Color(0xFF1B7A47);
      case 'Reminder':
        return const Color(0xFF8A6500);
      case 'Update':
        return const Color(0xFF315A78);
      default:
        return const Color(0xFF0F3D24);
    }
  }

  void _toast(String message, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: error ? const Color(0xFFB3261E) : null,
      ),
    );
  }

  String _friendly(Object e) {
    if (e is FirebaseException && e.code == 'permission-denied') {
      return 'Permission denied. Check your Firestore rules and that this '
          'account has role "admin".';
    }
    return 'Something went wrong: $e';
  }

  // ------------------------------------------------------------------
  // CREATE / EDIT
  // ------------------------------------------------------------------

  Future<void> _showNotificationDialog({AppNotification? existing}) async {
    final isEditing = existing != null;

    final titleController = TextEditingController(text: existing?.title ?? '');
    final messageController =
        TextEditingController(text: existing?.message ?? '');

    String selectedType = existing?.type ?? kNotificationTypes.first;
    final typeOptions = kNotificationTypes.contains(selectedType)
        ? kNotificationTypes
        : [...kNotificationTypes, selectedType];

    bool saving = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text(
                isEditing ? 'Edit Notification' : 'Create Notification',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      initialValue: selectedType,
                      decoration: InputDecoration(
                        labelText: 'Notification Type',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      items: typeOptions
                          .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                          .toList(),
                      onChanged: (value) {
                        if (value == null) return;
                        setDialogState(() => selectedType = value);
                      },
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: titleController,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: InputDecoration(
                        labelText: 'Title',
                        hintText: 'e.g. New Fixture Added',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: messageController,
                      maxLines: 4,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: InputDecoration(
                        labelText: 'Message',
                        hintText: 'Enter the notification message',
                        alignLabelWithHint: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: saving ? null : () => Navigator.pop(dialogContext),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0F3D24),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: saving
                      ? null
                      : () async {
                          final title = titleController.text.trim();
                          final message = messageController.text.trim();

                          if (title.isEmpty || message.isEmpty) {
                            _toast('Please complete all fields.', error: true);
                            return;
                          }

                          setDialogState(() => saving = true);

                          try {
                            if (existing != null) {
                              await Db.notifications.doc(existing.id).update({
                                'type': selectedType,
                                'title': title,
                                'message': message,
                              });
                            } else {
                              await Db.notifications.add({
                                'type': selectedType,
                                'title': title,
                                'message': message,
                                'createdAt': FieldValue.serverTimestamp(),
                              });
                            }

                            if (dialogContext.mounted) {
                              Navigator.pop(dialogContext);
                            }
                            _toast(
                              isEditing
                                  ? 'Notification updated.'
                                  : 'Notification sent to students.',
                            );
                          } catch (e) {
                            if (dialogContext.mounted) {
                              setDialogState(() => saving = false);
                            }
                            _toast(_friendly(e), error: true);
                          }
                        },
                  child: saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text(isEditing ? 'Save Changes' : 'Create'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // ------------------------------------------------------------------
  // DELETE
  // ------------------------------------------------------------------

  void _deleteNotification(AppNotification notification) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Delete Notification',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          content: Text(
            'Delete "${notification.title}"? It will disappear for students too.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFB3261E),
                foregroundColor: Colors.white,
              ),
              onPressed: () async {
                Navigator.pop(dialogContext);
                try {
                  await Db.notifications.doc(notification.id).delete();
                  _toast('Notification deleted.');
                } catch (e) {
                  _toast(_friendly(e), error: true);
                }
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  // ------------------------------------------------------------------
  // UI
  // ------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Manage Notifications',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF0F3D24),
        foregroundColor: Colors.white,
        onPressed: () => _showNotificationDialog(),
        icon: const Icon(Icons.add_rounded),
        label: const Text(
          'Create',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return _errorState(_friendly(snapshot.error!));
          }

          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(color: Color(0xFF1B7A47)),
            );
          }

          final items =
              snapshot.data!.docs.map(AppNotification.fromDoc).toList();

          if (items.isEmpty) return _emptyState();

          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
            itemCount: items.length,
            itemBuilder: (context, index) => _notificationCard(items[index]),
          );
        },
      ),
    );
  }

  Widget _notificationCard(AppNotification notification) {
    final type = notification.type;

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE1E6E2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: _typeColor(type).withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  type.toUpperCase(),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: _typeColor(type),
                  ),
                ),
              ),
              const Spacer(),
              PopupMenuButton<String>(
                icon: const Icon(
                  Icons.more_vert_rounded,
                  color: Color(0xFF68716B),
                ),
                onSelected: (value) {
                  if (value == 'edit') {
                    _showNotificationDialog(existing: notification);
                  }
                  if (value == 'delete') _deleteNotification(notification);
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit_rounded, size: 18),
                        SizedBox(width: 10),
                        Text('Edit'),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete_outline_rounded, size: 18),
                        SizedBox(width: 10),
                        Text('Delete'),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 13),
          Text(
            notification.title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: Color(0xFF141B16),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            notification.message,
            style: const TextStyle(
              fontSize: 13,
              height: 1.45,
              color: Color(0xFF68716B),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const Icon(
                Icons.access_time_rounded,
                size: 15,
                color: Color(0xFF9AA39D),
              ),
              const SizedBox(width: 5),
              Text(
                notification.timeAgo,
                style: const TextStyle(fontSize: 11, color: Color(0xFF9AA39D)),
              ),
              const Spacer(),
              const Icon(
                Icons.check_circle_rounded,
                size: 15,
                color: Color(0xFF1B7A47),
              ),
              const SizedBox(width: 5),
              const Text(
                'Live for students',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF1B7A47),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _errorState(String message) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              size: 46,
              color: Color(0xFFB3261E),
            ),
            const SizedBox(height: 14),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                height: 1.45,
                color: Color(0xFF68716B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F3EC),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Icon(
                Icons.notifications_none_rounded,
                size: 34,
                color: Color(0xFF0F3D24),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'No notifications yet',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: Color(0xFF141B16),
              ),
            ),
            const SizedBox(height: 7),
            const Text(
              'Create a notification to keep sports users updated.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF68716B),
                height: 1.4,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () => _showNotificationDialog(),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F3D24),
                foregroundColor: Colors.white,
              ),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Create Notification'),
            ),
          ],
        ),
      ),
    );
  }
}
