import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../services/db.dart';
import '../services/read_state.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  // Live feed: anything the admin creates, edits or deletes appears here
  // straight away. Created once so it isn't re-subscribed on every rebuild.
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream =
      Db.latestNotifications.snapshots();

  @override
  void initState() {
    super.initState();
    ReadState.instance.ensureLoaded();
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'Fixture':
        return Icons.calendar_month_rounded;
      case 'Result':
        return Icons.emoji_events_rounded;
      case 'Reminder':
        return Icons.notifications_active_rounded;
      default:
        return Icons.sync_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF0B2E1C);
    const primaryLight = Color(0xFF1E9553);
    const accent = Color(0xFFC6FF4D);
    const bg = Color(0xFFF4F7F3);
    const ink = Color(0xFF10160F);
    const inkSoft = Color(0xFF6C766A);
    const line = Color(0xFFE6EAE1);

    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _stream,
      builder: (context, snapshot) {
        final docs = snapshot.data?.docs ??
            <QueryDocumentSnapshot<Map<String, dynamic>>>[];
        final items = docs.map(AppNotification.fromDoc).toList();

        return ValueListenableBuilder<Set<String>?>(
          valueListenable: ReadState.instance.readIds,
          builder: (context, readIds, _) {
            final isLoading =
                (!snapshot.hasData && !snapshot.hasError) || readIds == null;

            final read = readIds ?? <String>{};
            final unreadCount = items.where((n) => !read.contains(n.id)).length;

            return Scaffold(
              backgroundColor: bg,
              appBar: AppBar(
                backgroundColor: bg,
                elevation: 0,
                scrolledUnderElevation: 0,
                titleSpacing: 20,
                title: const Text(
                  'Notifications',
                  style: TextStyle(
                    color: ink,
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.5,
                  ),
                ),
                actions: [
                  if (!isLoading && unreadCount > 0)
                    Padding(
                      padding: const EdgeInsets.only(right: 18),
                      child: TextButton(
                        onPressed: () => ReadState.instance
                            .markRead(items.map((n) => n.id)),
                        child: const Text(
                          'Mark all read',
                          style: TextStyle(
                            color: primaryLight,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              body: snapshot.hasError
                  ? const _ErrorNotifications()
                  : isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                            color: primaryLight,
                          ),
                        )
                      : items.isEmpty
                          ? const _EmptyNotifications()
                          : ListView(
                              padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
                              children: [
                                _NotificationSummary(
                                  unreadCount: unreadCount,
                                  primary: primary,
                                  accent: accent,
                                ),
                                const SizedBox(height: 22),
                                const Text(
                                  'Recent activity',
                                  style: TextStyle(
                                    color: ink,
                                    fontSize: 17,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                ...items.map(
                                  (n) => _NotificationCard(
                                    title: n.title,
                                    message: n.message,
                                    time: n.timeAgo,
                                    type: n.type,
                                    icon: _iconFor(n.type),
                                    unread: !read.contains(n.id),
                                    primary: primary,
                                    primaryLight: primaryLight,
                                    accent: accent,
                                    line: line,
                                    ink: ink,
                                    inkSoft: inkSoft,
                                    onTap: () =>
                                        ReadState.instance.markRead([n.id]),
                                  ),
                                ),
                              ],
                            ),
            );
          },
        );
      },
    );
  }
}

class _ErrorNotifications extends StatelessWidget {
  const _ErrorNotifications();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(35),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.cloud_off_rounded, size: 48, color: Color(0xFF9AA398)),
            SizedBox(height: 14),
            Text(
              'Could not load notifications',
              style: TextStyle(
                color: Color(0xFF10160F),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(height: 6),
            Text(
              'Check your connection and try again.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xFF6C766A), fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}

class _NotificationSummary extends StatelessWidget {
  final int unreadCount;
  final Color primary;
  final Color accent;

  const _NotificationSummary({
    required this.unreadCount,
    required this.primary,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: primary,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: primary.withValues(alpha: 0.14),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: accent,
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(
              Icons.notifications_rounded,
              color: Color(0xFF0B2E1C),
              size: 25,
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  unreadCount == 0
                      ? 'You are all caught up'
                      : '$unreadCount unread notification${unreadCount == 1 ? '' : 's'}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Stay updated with GZU Sports Hub.',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NotificationCard extends StatelessWidget {
  final String title;
  final String message;
  final String time;
  final String type;
  final IconData icon;
  final bool unread;
  final Color primary;
  final Color primaryLight;
  final Color accent;
  final Color line;
  final Color ink;
  final Color inkSoft;
  final VoidCallback onTap;

  const _NotificationCard({
    required this.title,
    required this.message,
    required this.time,
    required this.type,
    required this.icon,
    required this.unread,
    required this.primary,
    required this.primaryLight,
    required this.accent,
    required this.line,
    required this.ink,
    required this.inkSoft,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: unread
              ? Colors.white
              : Colors.white.withValues(alpha: 0.72),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: unread
                ? primaryLight.withValues(alpha: 0.20)
                : line,
          ),
          boxShadow: unread
              ? [
                  BoxShadow(
                    color: primary.withValues(alpha: 0.05),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ]
              : [],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: unread
                    ? accent.withValues(alpha: 0.32)
                    : const Color(0xFFECEFEC),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(
                icon,
                color: unread ? primary : inkSoft,
                size: 21,
              ),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          title,
                          style: TextStyle(
                            color: ink,
                            fontSize: 14.5,
                            fontWeight: unread
                                ? FontWeight.w800
                                : FontWeight.w700,
                          ),
                        ),
                      ),
                      if (unread)
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Color(0xFF1E9553),
                            shape: BoxShape.circle,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    message,
                    style: TextStyle(
                      color: inkSoft,
                      fontSize: 12.5,
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Text(
                        type.toUpperCase(),
                        style: TextStyle(
                          color: primaryLight,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 3,
                        height: 3,
                        decoration: BoxDecoration(
                          color: inkSoft.withValues(alpha: 0.5),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        time,
                        style: TextStyle(
                          color: inkSoft.withValues(alpha: 0.85),
                          fontSize: 10.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyNotifications extends StatelessWidget {
  const _EmptyNotifications();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(35),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F0E9),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Icon(
                Icons.notifications_none_rounded,
                color: Color(0xFF1E9553),
                size: 34,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'No notifications yet',
              style: TextStyle(
                color: Color(0xFF10160F),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 7),
            const Text(
              'New fixtures, results and sports updates will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF6C766A),
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}